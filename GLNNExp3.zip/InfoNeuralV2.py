
import random as rd
import numpy as np
import torch
import torch.nn as nn
from sklearn import datasets
import matplotlib.pyplot as plt


class TestNet(nn.Module):
    def __init__(self, in_d, out_d) -> None:
        super().__init__()
        self.classifier = nn.Sequential(
            nn.Linear(in_d, 64*in_d),
            nn.Sigmoid(),
            nn.Linear(64*in_d, 32*in_d),
            nn.Sigmoid(),
            nn.Linear(32*in_d, out_d),
            nn.Sigmoid()
        )
        self.in_ = 0
        self.linear_out = 0
        self.act_out = 0
    
    def forward(self, x):
        self.act_out = self.classifier(x)
        return self.act_out


class InfoNeuralPart(nn.Module):
    def __init__(self, local_feature, lr_g, lr_l_g, lr_l_outspace, out_d_global, out_d_local, rand_len, hid_d_global) -> None:# local feature 包含了global_feature
        super().__init__()
        # learning rate
        self.lr_g = lr_g
        self.lr_l_g = lr_l_g
        self.lr_l_outspace = lr_l_outspace

        # local info net
        info_l_o = out_d_local
        self.local_len = local_feature
        self.info_l = nn.Linear(local_feature, info_l_o)
        self.info_l_act = nn.Sigmoid()
        self.info_l_act_name = "sig"

        # global info net
        info_g_i = hid_d_global
        self.rand_len = rand_len
        self.info_g_i = nn.Linear(info_l_o+self.rand_len, info_g_i)
        self.info_g_i_act = nn.Sigmoid()
        self.info_g_i_act_name = "sig"
        self.info_g_o = nn.Linear(info_g_i, out_d_global)
        self.info_g_o_act = nn.Sigmoid()
        self.info_g_o_act_name = "sig"
        self.info_global_o_ = ""
        self.info_local_o_ = ""
        self.rand_tensor = torch.rand(self.rand_len)
        self.info_local_ = ""
        self.global_info_input = ""
        self.info_global_ = ""
        self.info_global_input_h = ""
        self.info_global_output_h = ""
        self.x_l = ""

    def forward(self, x_l, x_g):

        self.x_l = x_l
        self.info_local_ = self.info_l(x_l)
        self.info_local_o_ = self.info_l_act(self.info_local_)
        self.rand_tensor = torch.rand(self.rand_len)
        self.global_info_input = torch.cat((self.info_local_o_, self.rand_tensor))
        self.info_global_ = self.info_g_i(self.global_info_input)
        self.info_global_input_h = self.info_g_i_act(self.info_global_)
        self.info_global_output_h = self.info_g_o(self.info_global_input_h)
        self.info_global_o_ = self.info_g_o_act(self.info_global_output_h)

        # next layer input
        input_c = torch.cat((self.info_local_o_, self.info_global_o_, x_g))

        # get pred
        return input_c


class InfoNeuralLayer(nn.Module):
    def __init__(self, local_feature, global_feature, lr_g, lr_l_g, lr_l_outspace, lr, out_d) -> None:
        super().__init__()
        self.lr = lr
        self.hid_d_global = 16
        self.out_d_global = 2
        self.out_d_local = 2
        self.rand_len = 2
        self.info_part = InfoNeuralPart(local_feature, lr_g, lr_l_g, lr_l_outspace, self.out_d_global, self.out_d_local, self.rand_len, self.hid_d_global)
        self.linear = nn.Linear(self.out_d_global+self.out_d_local+global_feature, out_d)
        self.act = nn.Sigmoid()
        self.act_name = 'sig'
        self.linear_out = 0
        self.act_out = 0
        self.x_in = 0
        self.x_l = 0
        self.x_g = 0
    
    def forward(self, x_l, x_g):

        self.x_l = x_l
        self.x_g = x_g
        self.x_in = self.info_part(x_l, x_g)
        self.linear_out = self.linear(self.x_in)
        self.act_out = self.act(self.linear_out)
        return self.act_out

    def get_weight_info(self):
        return self.linear.weight.data
    
    def set_weight(self, weight):
        self.linear.weight.data = weight

    def print_weight(self):
        print(self.info_part.info_g_o.weight.data)


class InfoNeural(nn.Module):
    def __init__(self, local_d, global_d, out_d) -> None:
        super().__init__()
        self.infolayer1 = InfoNeuralLayer(local_d, global_d, 0.01, 0.01, 0.01, 0.01, 4*global_d)
        self.infolayer2 = InfoNeuralLayer(local_d + 4*global_d, 4*global_d, 0.01, 0.01, 0.01, 0.01, 2*global_d)
        self.infolayer3 = InfoNeuralLayer(local_d + 2*global_d, 2*global_d, 0.01, 0.01, 0.01, 0.01, out_d)
    
    def forward(self, x_l, x_g):
        pred = self.infolayer1(x_l, x_g)
        x = torch.concat([x_l, pred])
        pred = self.infolayer2(x, pred)
        x = torch.concat([x_l, pred])
        pred = self.infolayer3(x, pred)
        return pred
    
    def get_weight(self, layer):
        if layer == 0:
            return self.infolayer1.get_weight_info()
        if layer == 1:
            return self.infolayer2.get_weight_info()
        if layer == 2:
            return self.infolayer3.get_weight_info()

    def print_weight(self):
        self.infolayer1.print_weight()

    def set_weight(self, layer, weight):
        if layer == 0:
            return self.infolayer1.set_weight(weight)
        if layer == 1:
            return self.infolayer2.set_weight(weight)
        if layer == 2:
            return self.infolayer3.set_weight(weight)


def square_distribution(a, b, c, num):
    x = []
    y = []
    for i in range(num):
        t = rd.random()
        t2 = rd.random()
        x.append(np.array([t, t2]))
        if t2 > a*t*t + b*t + c:
            y.append(1)
        else:
            y.append(0)
    return x, y


def sin_distribution(A, b, w, num):
    x = []
    y = []
    for i in range(num):
        t = rd.random()
        t2 = rd.random()
        x.append(np.array([t, t2]))
        if t2 > A*np.sin(w*t+b):
            y.append(1)
        else:
            y.append(0)
    return x, y

def generate_data(hidden_feature):
    # first no hidden feature
    dataset = []
    if hidden_feature is False:
        #x_m, y_m = datasets.make_circles(noise=0.05)
        #x_c, y_c = datasets.make_circles(noise=0.05)
        x_m, y_m = square_distribution(0.85, -0.1, 0.2, 400)
        x_c, y_c = sin_distribution(1.2, 0.46, 0.73, 400)
        dataset1 = []
        dataset1_test = []
        dataset2 = []
        dataset2_test = []
        for i in range(len(x_m)):
            if rd.random() < 0.7:
                dataset1.append([x_m[i], y_m[i]])
                dataset2.append([x_c[i], y_c[i]])
            else:
                dataset1_test.append([x_m[i], y_m[i]])
                dataset2_test.append([x_c[i], y_c[i]])
        return [dataset1, dataset2, dataset1_test, dataset2_test]
    else:
        x_g, y_g = datasets.make_moons(noise=0.05)
        x_l_m, y_l_m = datasets.make_moons(noise=0.05)
        x_l_c, y_l_c = datasets.make_circles(noise=0.05)
        # dataset allocate
        dataset1 = []
        dataset1_test = []
        dataset2 = []
        dataset2_test = []
        for i in range(len(x_l_m)):
            if rd.random() < 0.7:
                dataset1.append([x_l_m[i], x_g[i], y_g[i]])
                dataset2.append([x_l_c[i], x_g[i], y_g[i]])
            else:
                dataset1_test.append([x_l_m[i], x_g[i], y_g[i]])
                dataset2_test.append([x_l_c[i], x_g[i], y_g[i]])
        return [dataset1, dataset2, dataset1_test, dataset2_test]


def test():
    hidden_feature = False
    dataset = generate_data(hidden_feature)
    train_sample = []
    for i in range(len(dataset)):
        train_sample.append(dataset[0][0])
    # set1
    #train_set1 = dataset[0]
    #train_sample.append(train_set1[0])
    # set2
    #train_set2 = dataset[1]
    # test_set1
    test_set1 = dataset[2]
    
    # test_set1
    test_set2 = dataset[3]

    # models
    classifier = TestNet(len(train_sample[0][0]), 1)
    net_list = []
    datasets_num = 2
    for i in range(datasets_num):
        net_list.append(InfoNeural(len(train_sample[i][0]), len(train_sample[i][0]), 1))


    # loss_fn
    loss_fn = nn.BCELoss()

    # optimizer
    optimizer_Avg = torch.optim.SGD(classifier.parameters(), lr=0.01)
    optimizer_info = []
    for i in range(len(net_list)):
        optimizer_info.append(torch.optim.SGD(net_list[i].parameters(),lr=0.01))

    echo = 300
    # loss_sum = 0
    loss_avg = []
    loss_net1 = []
    loss_net2 = []
    for e in range(echo):
        loss_sum_info = []
        loss_sum = 0
        for d in range(len(net_list)):
            loss_info = 0
            for i in range(len(dataset[d])):  # 训练第一个数据集
                sample_ = torch.tensor(dataset[d][i][0], dtype=torch.float32)
                label_ = torch.tensor(dataset[d][i][1], dtype=torch.float32).unsqueeze(0)
                pred_class = classifier(sample_)
                pred_info = net_list[d](sample_, sample_)
                loss = loss_fn(pred_class, label_)
                loss2 = loss_fn(pred_info, label_)
                loss_info += loss2.item()
                loss_sum += loss.item()
                optimizer_Avg.zero_grad()
                loss.backward()
                optimizer_Avg.step()
                optimizer_info[d].zero_grad()
                loss2.backward()
                optimizer_info[d].step()
            loss_sum_info.append(loss_info)
        '''
        for i in range(len(train_set2)):  # 训练第二个数据集
            sample_ = torch.tensor(train_set2[i][0], dtype=torch.float32)
            label_ = torch.tensor(train_set2[i][1], dtype=torch.float32).unsqueeze(0)
            pred_class = classifier(sample_)
            pred_info = net_list[1](sample_, sample_)
            loss = loss_fn(pred_class, label_)
            loss3 = loss_fn(pred_info, label_)
            loss_sum += loss.item()
            loss_sum3 += loss3.item()
            optimizer_Avg.zero_grad()
            loss.backward()
            optimizer_Avg.step()
            optimizer_info[1].zero_grad()
            loss3.backward()
            optimizer_info[1].step()
        '''
        loss_avg.append(loss_sum/len(dataset))
        #loss_net1.append(loss_sum2)
        #loss_net2.append(loss_sum3)
        #print(loss_sum/2, loss_sum2, loss_sum3, e)
        # 聚合操作
        for l in range(3):
            weight = 0
            for i in range(len(net_list)):
                weight += net_list[i].get_weight(l)
            weight = weight/len(net_list)
            for i in range(len(net_list)):
                net_list[i].set_weight(weight=weight, layer=l)

    correct_class = 0
    correct_net = 0
    correct_net2 = 0
    for i in range(len(test_set1)):
            sample_ = torch.tensor(test_set1[i][0], dtype=torch.float32)
            label_ = torch.tensor(test_set1[i][1], dtype=torch.float32).unsqueeze(0)
            sample_2 = torch.tensor(test_set2[i][0], dtype=torch.float32)
            label_2 = torch.tensor(test_set2[i][1], dtype=torch.float32).unsqueeze(0)
            pred_class = classifier(sample_)
            pred_info = net_list[0](sample_, sample_)
            pred_info2 = net_list[1](sample_2, sample_2)
            if (pred_class > 0.5 and 1 == label_) or (pred_class < 0.5 and 0 == label_):
                correct_class += 1
            if (pred_info > 0.5 and 1 == label_) or (pred_info < 0.5 and 0 == label_):
                correct_net += 1
            pred_class = classifier(sample_2)
            if (pred_class > 0.5 and 1 == label_2) or (pred_class < 0.5 and 0 == label_2):
                correct_class += 1
            if (pred_info2 > 0.5 and 1 == label_2) or (pred_info2 < 0.5 and 0 == label_2):
                correct_net2 += 1
            
    print(correct_class/(len(test_set1)*2), (correct_net/len(test_set1)+correct_net2/len(test_set2))/2)
    #x = range(0, echo)
    #labels = ["FedAvg, FedInfo2, FedInfo3"]
    #plt.plot(x, loss_avg)
    #plt.plot(x, loss_net1)
    #plt.plot(x, loss_net2)
    #plt.ylabel("loss")
    #plt.ylim(0, 250)
    #plt.xlabel(" rounds ")
    #plt.legend(labels)
    #plt.show()
    

test()



