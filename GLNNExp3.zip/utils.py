import random as rd
import numpy as np
import torch
import torch.nn as nn


class NeuralNetwork(nn.Module):
    def __init__(self, input_dimension, output_dimension) -> None:
        super().__init__()
        self.classification = nn.Sequential(
            nn.Linear(input_dimension, 4*input_dimension),
            nn.Tanh(),
            nn.Linear(4*input_dimension, 4*input_dimension),
            nn.Tanh(),
            nn.Linear(4*input_dimension, output_dimension),
            nn.Softmax(),
        )

    def forward(self,x):
        return self.classification(x)


def act_derivative(x, act):
    if act == 'sig':
        sig = nn.Sigmoid()
        return sig(x)*(1-sig(x))
    elif act == 'tanh':
        tanh = nn.Tanh()
        return 2*torch.pow(tanh(x), 3) - 2*tanh(x)
    return torch.ones_like(x)
    

def MSE_derivative(x, x_t):
    return x_t-x


def Softmax_derivative(x):
    x_ = x.detach().numpy()[0]
    temp = [[0 for i in range(len(x_))] for j in range(len(x_))]
    for i in range(len(x_)):
        for j in range(len(x_)):
            if i == j:
                temp[i][j] = x_[i]*(1-x_[j])
            else:
                temp[i][j] = -x_[i]*x_[j]
    #print(temp)
    return torch.tensor(temp, dtype=torch.float32)


def CrossEntropy_derivative(pred, label):
    pred = 1/pred
    return pred*label


def neural_derivative_w(in_put, w):
    print(in_put.shape)
    print(w.shape)
    return in_put


def neural_derivative_in(w):
    return w


class DerivativeChain():
    def __init__(self, model) -> None:
        self.model = model
    
    def derivative(self, x, layer, y_t, act):
        in_ = x
        temp = [in_]
        # temp.append(in_)
        for i in range(len(self.model)):
            x = self.model[i](x)
            temp.append(x)
        diff_chain = []
        for i in range(len(temp)-1, layer-1, -1):
            if i == len(temp)-1:
                diff_chain.append(CrossEntropy_derivative(temp[i], y_t))
                continue
            if i == layer-1:
                if i % 2 == 0:
                    diff_chain.append(neural_derivative_in(self.model[i].weight.data))
                    continue
                if i % 2 == -1:
                    diff_chain.append(neural_derivative_w(temp[i], self.model[i].weight.data))
                    continue
            if i % 2 == 1:
                if i == len(temp)-2:
                    diff_chain.append(Softmax_derivative(temp[i]))
                    continue
                diff_chain.append(act_derivative(temp[i], act))
                continue
            if i % 2 == 0:
                diff_chain.append(neural_derivative_in(self.model[i].weight.data))
                continue
        result = torch.tensor(1, dtype=torch.float32).unsqueeze(0)
        for i in range(len(diff_chain)):
            #print(result.shape)
            #print(diff_chain[i].shape)
            if i == 0:  # 初始化result
                result = torch.matmul(result, diff_chain[i])
                continue
            if i == 1:  # 损失函数和最外层激活函数求导
                for j in range(len(diff_chain[i])):
                    #print(result[j])
                    #print(diff_chain[i][j])
                    temp = result[j]*diff_chain[i][j]
                    diff_chain[i][j] = temp
                result = diff_chain[i]
                continue
            if i % 2 == 1:  # 上一层输出的偏导左乘这一层激活函数的偏导
                result = result.T
                for j in range(len(diff_chain[i][0])):
                    temp = result[j]*diff_chain[i][0][j]
                    result[j] = temp
                result = result.T
                continue
            if i % 2 == 0:  # 上一层激活函数的偏导乘这一层输入的偏导
                result = torch.matmul(result, diff_chain[i])

        return result


def get_mod(grads):
    mod = []
    for grad in grads:
        mod_ = grad.detach().numpy()
        mod.append(np.linalg.norm(mod_))

    sum_mod = sum(mod)
    if sum_mod == 0:
        mod = [1/len(grads)]*len(grads)
        return mod, mod.index(max(mod))
    for i in range(len(mod)):
        mod[i] = mod[i]/sum_mod
    return mod, mod.index(max(mod))


def test():
    model = NeuralNetwork(4, 6)
    diff_chain = DerivativeChain(model.classification)
    input_data = []
    label_data1 = []
    label_data2 = []
    for i in range(1, 101):
        input_data.append((torch.rand(1, 4)*2+np.log(i))/100)
        label_data1.append((torch.rand(1, 6)*2+np.log(i))/100)
        label_data2.append(input_data[i-1])
    echo = 100
    loss_fn = nn.CrossEntropyLoss()
    res_o = model(input_data[0])
    best = res_o
    min_loss = 9999
    # print(input_data[0][0])
    label_data1[0] = torch.tensor([[0, 0, 0, 0, 1, 0]], dtype=torch.float32)
    for e in range(echo):
        grad = diff_chain.derivative(input_data[0], 0, label_data1[0], 'tanh')
        res = model(input_data[0])
        #rate, maxed = get_mod(grad)
        #for i in range(len(grad)):
        #print(grad)
        #    if i != maxed:
        #        rate[i] = 0
        #    grad[i] = rate[i]*grad[i]
        loss = loss_fn(res, label_data1[0])
        print(loss)
        if loss < min_loss:
            min_loss = loss
            best = res

        # print(loss)
        # print(input_data[0][0])
        grad = grad.T.detach().numpy()
        mu = 0.008
        for i in range(len(grad)):
            input_data[0][0][i] += -mu * sum(grad[i])
        res = model(input_data[0])
        if loss_fn(res, label_data1[0]) > loss:
            for i in range(len(grad)):
                input_data[0][0][i] += mu * sum(grad[i])
    print(res_o)
    print(best)
    print(label_data1[0])
    print(input_data[0][0])


# test()

