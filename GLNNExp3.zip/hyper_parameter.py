import csv
from operator import le
import random as rd
import weakref
import numpy as np
import torch
import torch.nn as nn
from sklearn import datasets
import matplotlib.pyplot as plt
import torch.nn.functional as func
from torch.utils.data import DataLoader

torch.set_default_tensor_type(torch.DoubleTensor)

class InfoNeuralPart(nn.Module):
    def __init__(self, local_feature, lr_g, lr_l_g, lr_l_outspace, out_d_global, out_d_local, rand_len, hid_d_global) -> None:# local feature 包含了global_feature
        super().__init__()
        # learning rate
        self.lr_g = lr_g
        self.lr_l_g = lr_l_g
        self.lr_l_outspace = lr_l_outspace

        # local info net
        info_l_o = out_d_local
        self.local_len = local_feature
        self.info_l = nn.Linear(local_feature, info_l_o)
        self.info_l_act = nn.Sigmoid()
        self.info_l_act_name = "sig"

        # global info net
        info_g_i = hid_d_global
        self.rand_len = rand_len
        self.info_g_i = nn.Linear(info_l_o+self.rand_len, info_g_i)
        self.info_g_i_act = nn.Sigmoid()
        self.info_g_i_act_name = "sig"
        self.info_g_o = nn.Linear(info_g_i, out_d_global)
        self.info_g_o_act = nn.Sigmoid()
        self.info_g_o_act_name = "sig"
        self.info_global_o_ = ""
        self.info_local_o_ = ""
        self.rand_tensor = torch.rand(self.rand_len)
        self.info_local_ = ""
        self.global_info_input = ""
        self.info_global_ = ""
        self.info_global_input_h = ""
        self.info_global_output_h = ""
        self.x_l = ""

    def forward(self, x_l, x_g):
        # x_l contains x_g
        # get info_l and info_g
        #with torch.no_grad():
        self.x_l = x_l
        self.info_local_ = self.info_l(x_l)
        self.info_local_o_ = self.info_l_act(self.info_local_)
        if self.info_local_o_.ndim == 2:
            self.rand_tensor = torch.rand((len(self.info_local_o_), self.rand_len))
            self.global_info_input = torch.cat((self.info_local_o_, self.rand_tensor), dim=1)
        else:
            self.rand_tensor = torch.rand(self.rand_len)
            self.global_info_input = torch.cat((self.info_local_o_, self.rand_tensor))
        self.info_global_ = self.info_g_i(self.global_info_input)
        self.info_global_input_h = self.info_g_i_act(self.info_global_)
        self.info_global_output_h = self.info_g_o(self.info_global_input_h)
        self.info_global_o_ = self.info_g_o_act(self.info_global_output_h)

        # next layer input
        if self.info_local_o_.ndim == 2:
            input_c = torch.cat((self.info_local_o_, self.info_global_o_, x_g), dim=1)
        else:
            input_c = torch.cat((self.info_local_o_, self.info_global_o_, x_g))

        # get pred
        return input_c

class InfoNeuralLayer(nn.Module):
    def __init__(self, local_feature, global_feature, lr_g, lr_l_g, lr_l_outspace, lr, out_d, hyper_param) -> None:
        super().__init__()
        self.lr = lr
        self.hid_d_global = 32
        self.out_d_global = 2
        self.out_d_local = hyper_param
        self.rand_len = 2
        self.info_part = InfoNeuralPart(local_feature, lr_g, lr_l_g, lr_l_outspace, self.out_d_global, self.out_d_local, self.rand_len, self.hid_d_global)
        self.linear = nn.Linear(self.out_d_global+self.out_d_local+global_feature, out_d)
        self.act = nn.Sigmoid()
        self.act_name = 'sig'
        self.linear_out = 0
        self.act_out = 0
        self.x_in = 0
        self.x_l = 0
        self.x_g = 0
    
    def forward(self, x_l, x_g):
        #with torch.no_grad():
        self.x_l = x_l
        self.x_g = x_g
        self.x_in = self.info_part(x_l, x_g)
        self.linear_out = self.linear(self.x_in)
        self.act_out = self.act(self.linear_out)
        return self.act_out
    

    def get_weight_info(self):
        return self.linear.weight.data# , self.info_part.info_global_o_
    
    def set_weight(self, weight):
        self.linear.weight.data = weight

class InfoNeural(nn.Module):
    def __init__(self, local_d, global_d, out_d, hyper_param) -> None:
        super().__init__()
        self.infolayer1 = InfoNeuralLayer(local_d, global_d, 0.01, 0.01, 0.01, 0.01, out_d, hyper_param)
    
    def forward(self, x_l, x_g):
        pred = self.infolayer1(x_l, x_g)
        return pred
    
    def back_probagation(self, grad):
        grad = self.infolayer3.back_propagation(grad)
        grad = self.infolayer2.back_propagation(grad)
        self.infolayer1.back_propagation(grad)
    
    def get_weight(self, layer):
        if layer == 0:
            return self.infolayer1.get_weight_info()
        if layer == 1:
            return self.infolayer2.get_weight_info()
        if layer == 2:
            return self.infolayer3.get_weight_info()
    
    def set_weight(self, layer, weight):
        if layer == 0:
            return self.infolayer1.set_weight(weight)
        if layer == 1:
            return self.infolayer2.set_weight(weight)
        if layer == 2:
            return self.infolayer3.set_weight(weight)

def generate_data(hidden_feature):
    # first no hidden feature
    dataset = []
    if hidden_feature is False:
        x_m, y_m = datasets.make_circles(noise=0.05)
        x_c, y_c = datasets.make_moons(noise=0.05)
        dataset1 = []
        dataset1_test = []
        dataset2 = []
        dataset2_test = []
        for i in range(len(x_m)):
            if rd.random() < 0.7:
                dataset1.append([x_m[i], y_m[i]/1.0])
                dataset2.append([x_c[i], y_c[i]/1.0])
            else:
                dataset1_test.append([x_m[i], y_m[i]/1.0])
                dataset2_test.append([x_c[i], y_c[i]/1.0])
        return [dataset1, dataset2, dataset1_test, dataset2_test]
    else:
        x_g, y_g = datasets.make_moons(noise=0.05)
        x_l_m, y_l_m = datasets.make_moons(noise=0.05)
        x_l_c, y_l_c = datasets.make_circles(noise=0.05)
        # dataset allocate
        dataset1 = []
        dataset1_test = []
        dataset2 = []
        dataset2_test = []
        for i in range(len(x_l_m)):
            if rd.random() < 0.7:
                dataset1.append([x_l_m[i], x_g[i], y_g[i]])
                dataset2.append([x_l_c[i], x_g[i], y_g[i]])
            else:
                dataset1_test.append([x_l_m[i], x_g[i], y_g[i]])
                dataset2_test.append([x_l_c[i], x_g[i], y_g[i]])
        return [dataset1, dataset2, dataset1_test, dataset2_test]

def test(hyper_param, dataset):
    
    # set1
    train_set1 = dataset[0]

    # set2
    train_set2 = dataset[1]

    test_set1 = dataset[2]
    test_set2 = dataset[3]

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    glnn_net1 = InfoNeural(len(train_set1[0][0]), len(train_set1[0][0]), 1, hyper_param).to(device)
    glnn_net2 = InfoNeural(len(train_set2[0][0]), len(train_set2[0][0]), 1, hyper_param).to(device)

    loss_fn = nn.BCELoss()
    optimizer_glnn1 = torch.optim.SGD(glnn_net1.parameters(), lr=0.01)
    optimizer_glnn2 = torch.optim.SGD(glnn_net2.parameters(), lr=0.01)
    loss_glnn = 0

    echo = 100
    b_size = 50
    for e in range(echo):

        data = DataLoader(train_set1, batch_size=b_size)
        for sample_, label_ in data:# 训练第一个数据集
            pred1 = glnn_net1(sample_, sample_)
            loss1 = loss_fn(pred1, label_.unsqueeze(-1))
            optimizer_glnn1.zero_grad()
            loss1.backward()
            optimizer_glnn1.step()
            loss_glnn += loss1.item()
            

        data = DataLoader(train_set2, batch_size=b_size)
        for sample_, label_ in data:# 训练第二个数据集
            pred2 = glnn_net2(sample_, sample_)
            loss2 = loss_fn(pred2,label_.unsqueeze(-1))
            optimizer_glnn2.zero_grad()
            loss2.backward()
            optimizer_glnn2.step()
            loss_glnn+=loss2.item()
        
        
        weight = (glnn_net1.get_weight(0)+glnn_net2.get_weight(0))/2
        glnn_net1.set_weight(0,weight)
        glnn_net2.set_weight(0,weight)

    acc_glnn1 = 0
    acc_glnn2 = 0
    for i in range(len(test_set1)):
        sample_ = torch.tensor(test_set1[i][0], dtype=torch.float64)
        label_ = torch.tensor(test_set1[i][1], dtype=torch.float64)
        sample_2 = torch.tensor(test_set2[i][0], dtype=torch.float64)
        label_2 = torch.tensor(test_set2[i][1], dtype=torch.float64)
        pred1 = glnn_net1(sample_, sample_)
        pred2 = glnn_net2(sample_2, sample_2)
        if pred1 > 0.5 and label_ == 1 or pred1 < 0.5 and label_ == 0:
            acc_glnn1 += 1
        if pred2 > 0.5 and label_2 == 1 or pred2 < 0.5 and label_2 == 0:
            acc_glnn2 += 1

    return (acc_glnn2+acc_glnn1)/(len(test_set1)+len(test_set2))

conclusion = []
hidden_feature = False
dataset = generate_data(hidden_feature)
for hyperd_param in range(1,100):
    res = 0
    for m in range(20):
        res += test(hyperd_param, dataset)
    conclusion.append([hyperd_param,res/20])

f = open("hyper_param/out_d_local.csv",'w',newline="")
writer = csv.writer(f)
writer.writerows(conclusion)