import torch
import torch.nn as nn
import torch.nn.functional as func
from InfoNeural import DigitModel
import random as rd
from sklearn import datasets
import matplotlib.pyplot as plt
import torch.nn.functional as func
from torch.utils.data import DataLoader
import numpy as np

class FedBN(nn.Module):
    """
    Model for benchmark experiment on Digits. 
    """
    def __init__(self, in_d, out_d):
        super(FedBN, self).__init__()
        self.fc1 = nn.Linear(in_d, 32*in_d)
        self.bn4 = nn.BatchNorm1d(32*in_d)
        self.fc2 = nn.Linear(32*in_d, 16*in_d)
        self.bn5 = nn.BatchNorm1d(16*in_d)
        self.fc3 = nn.Linear(16*in_d, out_d)


    def forward(self, x):
        x = self.fc1(x)
        x = self.bn4(x)
        x = func.relu(x)

        x = self.fc2(x)
        x = self.bn5(x)
        x = func.relu(x)

        x = self.fc3(x)
        x = func.sigmoid(x)
        return x
    
    def get_weight(self, layer):
        if layer == 1:
            return self.fc1.weight.data
        if layer == 2:
            return self.fc2.weight.data
        if layer == 3:
            return self.fc3.weight.data


def linear_distribution(a, b, num):
    x = []
    y = []
    steps = 5/num
    t = - steps
    t2 = - steps
    for e in range(num):
        t += steps
        for i in range(num):
            t2 += steps 
            x.append(np.array([t, t2]))
            if t2 > a*t:
                y.append(1.0)
            else:
                y.append(0.0)
        t2 = 0
    return x, y

def experimental_distribution(A, b, num):
    x = []
    y = []
    steps = 5/num
    t = -steps
    t2 = -steps
    if b != 'c':
        for e in range(num):
            t2 += steps
            for i in range(num):
                t += steps
                x.append(np.array([t, t2]))
                if b < 180:
                    if A > 0.999999:
                        if t2 > A*t - 2.5*(A-1):
                            y.append(1.0)
                        else:
                            y.append(0.0)
                    elif A < 1:
                        if t2 < A*t - 2.5*(A-1):
                            y.append(1.0)
                        else:
                            y.append(0.0)
                else:
                    if A > 0.999999:
                        if t2 < A*t - 2.5*(A-1):
                            y.append(1.0)
                        else:
                            y.append(0.0)
                    elif A < 1:
                        if t2 > A*t - 2.5*(A-1):
                            y.append(1.0)
                        else:
                            y.append(0.0)
            t = 0
        return x, y
    else:
        for i in range(num):
            t = rd.random()*10 
            t2 = rd.random()*10 
            x.append(np.array([t, t2]))
            if t < 5:
                y.append(1.0)
            else:
                y.append(0.0)
        return x, y

def generate_data(hidden_feature, k, i):
    # first no hidden feature
    dataset = []
    if hidden_feature is False:
        #x_m, y_m = datasets.make_circles(noise=0.05)
        #x_c, y_c = datasets.make_circles(noise=0.05)
        x_m, y_m = linear_distribution(1, 1, 50)
        x_c, y_c = experimental_distribution(k, i, 50)
        dataset1 = []
        dataset1_test = []
        dataset2 = []
        dataset2_test = []
        for i in range(len(x_m)):
            if rd.random() < 0.7:
                dataset1.append([x_m[i], y_m[i]])
                dataset2.append([x_c[i], y_c[i]])
            else:
                dataset1_test.append([x_m[i], y_m[i]])
                dataset2_test.append([x_c[i], y_c[i]])
        return [dataset1, dataset2, dataset1_test, dataset2_test]
    else:
        x_g, y_g = datasets.make_moons(noise=0.05)
        x_l_m, y_l_m = datasets.make_moons(noise=0.05)
        x_l_c, y_l_c = datasets.make_circles(noise=0.05)
        # dataset allocate
        dataset1 = []
        dataset1_test = []
        dataset2 = []
        dataset2_test = []
        for i in range(len(x_l_m)):
            if rd.random() < 0.7:
                dataset1.append([x_l_m[i], x_g[i], y_g[i]])
                dataset2.append([x_l_c[i], x_g[i], y_g[i]])
            else:
                dataset1_test.append([x_l_m[i], x_g[i], y_g[i]])
                dataset2_test.append([x_l_c[i], x_g[i], y_g[i]])
        return [dataset1, dataset2, dataset1_test, dataset2_test]


def test(k, i2):
    hidden_feature = False
    dataset = generate_data(hidden_feature, k, i2)
    # set1
    train_set1 = dataset[0]
    train_sample1 = train_set1[0]
    # set2
    train_set2 = dataset[1]
    train_sample2 = train_set2[0]
    # test_set1
    test_set1 = dataset[2]
    test_sample1 = test_set1[0]
    
    # test_set1
    test_set2 = dataset[3]
    test_sample2 = test_set2[0]

    # models
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    fed_bn = DigitModel(len(train_sample1[0]), 1).to(device)
    fed_bn2 = DigitModel(len(train_sample1[0]), 1).to(device)
    optimizer_bn1 = torch.optim.SGD(fed_bn.parameters(), lr=0.01)
    optimizer_bn2 = torch.optim.SGD(fed_bn2.parameters(), lr=0.01)
    # tool = DerivativeChain(classifier.classification)
    echo = 200
    loss_fn = nn.BCELoss()
    b_size = 50

    for e in range(echo):
        loss_sum1 = 0
        loss_sum2 = 0
        fed_bn.train()
        fed_bn2.train()
        data = DataLoader(train_set1, batch_size=b_size)
        for sample_, label_ in data:
            pred_bn = fed_bn(sample_)
            label_ = label_.unsqueeze(-1)
            loss_bn = loss_fn(pred_bn, label_)
            optimizer_bn1.zero_grad()
            loss_bn.backward()
            optimizer_bn1.step()
            loss_sum1 += loss_bn.item()
        data = DataLoader(train_set2, batch_size=b_size)   
        for sample_, label_ in data:
            pred_bn = fed_bn2(sample_)
            label_ = label_.unsqueeze(-1)
            loss_bn = loss_fn(pred_bn, label_)
            optimizer_bn2.zero_grad()
            loss_bn.backward()
            optimizer_bn2.step()
            loss_sum2 += loss_bn.item()
        print(loss_sum1, loss_sum2)

        for l in range(3):
            weight = (fed_bn.get_weight(l) + fed_bn2.get_weight(l))/2
            fed_bn.set_weight(l, weight)
            fed_bn2.set_weight(l, weight)

for i in range(0, 220, 60):
    j = i+45
    du = (2*np.pi)*(j/360)
    k = np.tan(du)
    print(i)
    test(k,i)