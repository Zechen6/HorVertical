
import csv
from operator import le
import random as rd
import weakref
import numpy as np
import torch
import torch.nn as nn
from sklearn import datasets
import matplotlib.pyplot as plt
import torch.nn.functional as func
from torch.utils.data import DataLoader

torch.set_default_tensor_type(torch.DoubleTensor)

def Softmax_derivative(x):
    x_ = x.detach().numpy()[0]
    temp = [[0 for i in range(len(x_))] for j in range(len(x_))]
    for i in range(len(x_)):
        for j in range(len(x_)):
            if i == j:
                temp[i][j] = x_[i]*(1-x_[j])
            else:
                temp[i][j] = -x_[i]*x_[j]
    #print(temp)
    return torch.tensor(temp, dtype=torch.float32)

def CrossEntropy_derivative(pred, label):
    if pred == 0:
        pred = 0.00001
    pred = (1/pred)*label - (1-label)/(1-pred)
    return -pred

def act_derivative(x, act):
    if act == 'sig':
        sig = nn.Sigmoid()
        return sig(x)*(1-sig(x))
    elif act == 'tanh':
        tanh = nn.Tanh()
        return 2*torch.pow(tanh(x), 3) - 2*tanh(x)
    return torch.ones_like(x)


def neural_derivative_w(in_put, w):
    # print(in_put.shape)
    in_put = in_put.unsqueeze(0)
    res = in_put
    for i in range(len(w)-1):
        res = torch.concat([res, in_put], dim=0)
    return res


def neural_derivative_in(w):
    return w

class DigitModel(nn.Module):
    """
    Model for benchmark experiment on Digits. 
    """
    def __init__(self, in_di, num_classes):
        super().__init__()

        #self.conv1 = nn.Conv2d(3, 64, 5, 1, 2)
        #self.bn1 = nn.BatchNorm2d(64)
        #self.conv2 = nn.Conv2d(64, 64, 5, 1, 2)
        #self.bn2 = nn.BatchNorm2d(64)
        #self.conv3 = nn.Conv2d(64, 128, 5, 1, 2)
        #self.bn3 = nn.BatchNorm2d(128)
    
        #self.fc1 = nn.Linear(6272, 2048)
        #self.bn4 = nn.BatchNorm1d(2048)
        #self.fc2 = nn.Linear(2048, 512)
        #self.bn5 = nn.BatchNorm1d(512)
        #self.fc3 = nn.Linear(512, num_classes)
        #self.classification = nn.Sequential(
        #    nn.Linear(in_di, 120),
        #    #nn.BatchNorm1d(120),
        #    nn.ReLU(),
        #    nn.Linear(120, 120),
        #    #nn.BatchNorm1d(120),
        #    nn.ReLU(),
        #    nn.Linear(120, num_classes),
        #    nn.Softmax()
        #)
        self.classification = nn.Sequential(
            nn.Linear(in_di,32),
            nn.ReLU(),
            nn.BatchNorm1d(32),
            nn.Linear(32,16),
            nn.ReLU(),
            nn.BatchNorm1d(16),
            nn.Linear(16,num_classes),
            nn.Sigmoid(),
            #nn.Softmax()
        )
        self.fc1 = nn.Linear(in_di, 32)
        #self.bn4 = nn.BatchNorm1d(32)
        self.fc2 = nn.Linear(32, 16)
        #self.bn5 = nn.BatchNorm1d(16)
        self.fc3 = nn.Linear(16, num_classes)
        self.soft = nn.Softmax()
        self.model_list = ['0','3', '6']

    def set_weight(self, level, weight_outspace):
        self.classification._modules[self.model_list[level]].weight.data = weight_outspace
        #if level == 0:
        #    self.fc1.weight.data = weight_outspace
        #if level == 1:
        #    self.fc2.weight.data = weight_outspace
        #if level == 2:
        #    self.fc3.weight.data = weight_outspace

    def get_weight(self, level):
        return self.classification._modules[self.model_list[level]].weight.data
        #if level == 0:
        #    return self.fc1.weight.data
        #if level == 1:
        #    return self.fc2.weight.data
        #if level == 2:
        #    return self.fc3.weight.data

    def forward(self, x):
        #x = func.relu(self.bn1(self.conv1(x)))
        #x = func.max_pool2d(x, 2)

        #x = func.relu(self.bn2(self.conv2(x)))
        #x = func.max_pool2d(x, 2)

        #x = func.relu(self.bn3(self.conv3(x)))

        #x = x.view(x.shape[0], -1)

        #x = self.fc1(x)
        #x = self.bn4(x)
        #x = func.relu(x)

        #x = self.fc2(x)
        #x = self.bn5(x)
        #x = func.tanh(x)

        #x = self.fc3(x)
        #x = self.soft(x)
        x = self.classification(x)
        return x

class PartialNet(nn.Module):
    def __init__(self, in_d, out_d) -> None:
        super().__init__()
        self.classifier = nn.Sequential(
            nn.Linear(in_d, 64*in_d),
            nn.Sigmoid(),
            nn.Linear(64*in_d, 32),
            nn.Sigmoid(),
            nn.Linear(32, out_d),
            nn.Sigmoid()
        )
        self.in_ = 0
        self.linear_out = 0
        self.act_out = 0
    
    def forward(self, x):
        #self.in_ = x
        #self.linear_out = self.classifier[0](x)
        #self.act_out = self.classifier[1](self.linear_out)
        self.act_out = self.classifier(x)
        return self.act_out

    def set_weight(self, layer, weight):
        if layer == 0:
            self.classifier._modules['0'].weight.data = weight
        if layer == 1:
            self.classifier._modules['2'].weight.data = weight
        if layer == 2:
            self.classifier._modules['4'].weight.data =weight
    
    def get_weight(self, layer):
        if layer == 0:
            g =  self.classifier._modules['0'].weight
            return g
        if layer == 1:
            return self.classifier._modules['2'].weight
        if layer == 2:
            return self.classifier._modules['4'].weight

class TestNet(nn.Module):
    def __init__(self, in_d, out_d) -> None:
        super().__init__()
        self.classifier = nn.Sequential(
            nn.Linear(in_d, 64*in_d),
            nn.Sigmoid(),
            nn.Linear(64*in_d, 32*in_d),
            nn.Sigmoid(),
            nn.Linear(32*in_d, out_d),
            nn.Sigmoid()
        )
        self.in_ = 0
        self.linear_out = 0
        self.act_out = 0
    
    def forward(self, x):
        #self.in_ = x
        #self.linear_out = self.classifier[0](x)
        #self.act_out = self.classifier[1](self.linear_out)
        self.act_out = self.classifier(x)
        return self.act_out

    def set_weight(self, layer, weight):
        if layer == 0:
            self.classifier._modules['0'].weight.data = weight
        if layer == 1:
            self.classifier._modules['2'].weight.data = weight
        if layer == 2:
            self.classifier._modules['4'].weight.data =weight
    
    def get_weight(self, layer):
        if layer == 0:
            g =  self.classifier._modules['0'].weight
            return g
        if layer == 1:
            return self.classifier._modules['2'].weight
        if layer == 2:
            return self.classifier._modules['4'].weight

class InfoNeuralPart(nn.Module):
    def __init__(self, local_feature, lr_g, lr_l_g, lr_l_outspace, out_d_global, out_d_local, rand_len, hid_d_global) -> None:# local feature 包含了global_feature
        super().__init__()
        # learning rate
        self.lr_g = lr_g
        self.lr_l_g = lr_l_g
        self.lr_l_outspace = lr_l_outspace

        # local info net
        info_l_o = out_d_local
        self.local_len = local_feature
        self.info_l = nn.Linear(local_feature, info_l_o)
        self.info_l_act = nn.Sigmoid()
        self.info_l_act_name = "sig"

        # global info net
        info_g_i = hid_d_global
        self.rand_len = rand_len
        self.info_g_i = nn.Linear(info_l_o+self.rand_len, info_g_i)
        self.info_g_i_act = nn.Sigmoid()
        self.info_g_i_act_name = "sig"
        self.info_g_o = nn.Linear(info_g_i, out_d_global)
        self.info_g_o_act = nn.Sigmoid()
        self.info_g_o_act_name = "sig"
        self.info_global_o_ = ""
        self.info_local_o_ = ""
        self.rand_tensor = torch.rand(self.rand_len)
        self.info_local_ = ""
        self.global_info_input = ""
        self.info_global_ = ""
        self.info_global_input_h = ""
        self.info_global_output_h = ""
        self.x_l = ""

    def forward(self, x_l, x_g):
        # x_l contains x_g
        # get info_l and info_g
        #with torch.no_grad():
        self.x_l = x_l
        self.info_local_ = self.info_l(x_l)
        self.info_local_o_ = self.info_l_act(self.info_local_)
        if self.info_local_o_.ndim == 2:
            self.rand_tensor = torch.rand((len(self.info_local_o_), self.rand_len))
            self.global_info_input = torch.cat((self.info_local_o_, self.rand_tensor), dim=1)
        else:
            self.rand_tensor = torch.rand(self.rand_len)
            self.global_info_input = torch.cat((self.info_local_o_, self.rand_tensor))
        self.info_global_ = self.info_g_i(self.global_info_input)
        self.info_global_input_h = self.info_g_i_act(self.info_global_)
        self.info_global_output_h = self.info_g_o(self.info_global_input_h)
        self.info_global_o_ = self.info_g_o_act(self.info_global_output_h)

        # next layer input
        if self.info_local_o_.ndim == 2:
            input_c = torch.cat((self.info_local_o_, self.info_global_o_, x_g), dim=1)
        else:
            input_c = torch.cat((self.info_local_o_, self.info_global_o_, x_g))

        # get pred
        return input_c

class InfoNeuralLayer(nn.Module):
    def __init__(self, local_feature, global_feature, lr_g, lr_l_g, lr_l_outspace, lr, out_d) -> None:
        super().__init__()
        self.lr = lr
        self.hid_d_global = 32
        self.out_d_global = 2
        self.out_d_local = 32
        self.rand_len = 2
        self.info_part = InfoNeuralPart(local_feature, lr_g, lr_l_g, lr_l_outspace, self.out_d_global, self.out_d_local, self.rand_len, self.hid_d_global)
        self.linear = nn.Linear(self.out_d_global+self.out_d_local+global_feature, out_d)
        self.act = nn.Sigmoid()
        self.act_name = 'sig'
        self.linear_out = 0
        self.act_out = 0
        self.x_in = 0
        self.x_l = 0
        self.x_g = 0
    
    def forward(self, x_l, x_g):
        #with torch.no_grad():
        self.x_l = x_l
        self.x_g = x_g
        self.x_in = self.info_part(x_l, x_g)
        self.linear_out = self.linear(self.x_in)
        self.act_out = self.act(self.linear_out)
        return self.act_out
    

    def get_weight_info(self):
        return self.linear.weight.data# , self.info_part.info_global_o_
    
    def set_weight(self, weight):
        self.linear.weight.data = weight

class InfoNeural(nn.Module):
    def __init__(self, local_d, global_d, out_d) -> None:
        super().__init__()
        self.infolayer1 = InfoNeuralLayer(local_d, global_d, 0.01, 0.01, 0.01, 0.01, 4*global_d)
        self.infolayer2 = InfoNeuralLayer(local_d + 4*global_d, 4*global_d, 0.01, 0.01, 0.01, 0.01, 2*global_d)
        self.infolayer3 = InfoNeuralLayer(local_d + 2*global_d, 2*global_d, 0.01, 0.01, 0.01, 0.01, out_d)
    
    def forward(self, x_l, x_g):
        pred = self.infolayer1(x_l, x_g)
        if x_l.ndim == 2:
            x = torch.cat([x_l, pred], dim=1)
            pred = self.infolayer2(x, pred)
            x = torch.cat([x_l, pred], dim=1)
            pred = self.infolayer3(x, pred)
        else:
            x = torch.cat([x_l, pred])
            pred = self.infolayer2(x, pred)
            x = torch.cat([x_l, pred])
            pred = self.infolayer3(x, pred)
        return pred
    
    def back_probagation(self, grad):
        grad = self.infolayer3.back_propagation(grad)
        grad = self.infolayer2.back_propagation(grad)
        self.infolayer1.back_propagation(grad)
    
    def get_weight(self, layer):
        if layer == 0:
            return self.infolayer1.get_weight_info()
        if layer == 1:
            return self.infolayer2.get_weight_info()
        if layer == 2:
            return self.infolayer3.get_weight_info()
    
    def set_weight(self, layer, weight):
        if layer == 0:
            return self.infolayer1.set_weight(weight)
        if layer == 1:
            return self.infolayer2.set_weight(weight)
        if layer == 2:
            return self.infolayer3.set_weight(weight)
        
# decoupling
class Decoupling(nn.Module):
    def __init__(self, in_d, out_d) -> None:
        super().__init__()
        self.classifier = nn.Sequential(
            nn.Linear(in_d, 64*in_d),
            nn.Sigmoid(),
            nn.Linear(64*in_d, 32*in_d),
            nn.Sigmoid(),
            nn.Linear(32*in_d, out_d),
            nn.Sigmoid()
        )
        self.in_ = 0
        self.linear_out = 0
        self.act_out = 0
        self.properation = 0.5
        self.global_index1 = int(np.floor(self.properation*len(self.properation*self.classifier._modules['0'].weight)))
        self.global_index2 = int(np.floor(self.properation*len(self.properation*self.classifier._modules['2'].weight)))
        self.global_index3 = int(np.floor(self.properation*len(self.properation*self.classifier._modules['4'].weight)))
    
    def forward(self, x):
        #self.in_ = x
        #self.linear_out = self.classifier[0](x)
        #self.act_out = self.classifier[1](self.linear_out)
        self.act_out = self.classifier(x)
        return self.act_out

    def set_weight(self, layer, weight):
        if layer == 0:
            for i in range(len(weight)):
                self.classifier._modules['0'].weight.data[i+self.global_index1] = weight[i]
        if layer == 1:
            for i in range(len(weight)):
                self.classifier._modules['2'].weight.data[i+self.global_index2] = weight[i]
        if layer == 2:
            for i in range(len(weight)):
                self.classifier._modules['4'].weight.data[i+self.global_index3] = weight[i]
    
    def get_weight(self, layer):
        if layer == 0:
            g =  self.classifier._modules['0'].weight
            global_tensor = torch.zeros([int((len(g)-self.global_index1)),int(len(g[0]))])
            for i in range(len(global_tensor)):
                global_tensor[i] = g[i+self.global_index1]
            return global_tensor
        if layer == 1:
            g =  self.classifier._modules['2'].weight
            global_tensor = torch.zeros([int((len(g)-self.global_index2)),int(len(g[0]))])
            for i in range(len(global_tensor)):
                global_tensor[i] = g[i+self.global_index2]
            return global_tensor
        if layer == 2:
            g =  self.classifier._modules['4'].weight
            global_tensor = torch.zeros([int((len(g)-self.global_index3)),int(len(g[0]))])
            for i in range(len(global_tensor)):
                global_tensor[i] = g[i+self.global_index3]
            return global_tensor

def linear_distribution(a, b, num, w):
    x_g = []
    x_p_1 = []
    x_p_2 = []
    y = []
    steps = 10/num
    t = -5+steps
    t2 = -5+steps
    t3 = -5+steps
    t4 = -5+steps
    t5 = -5+steps
    t6 = -5+steps
    t7 = -5+steps

    for e in range(num+1):
        t += steps
        for i in range(num+1):
            t2 += steps
            for j in range(num+1):
                t3 += steps
                for jj in range(num+1):
                    t4 += steps
                    for jjj in range(num+1):
                        t5 += steps
                        for jjjj in range(num+1):
                            t6 = t6 + steps
                            for jjjjj in range(num+1):
                                t7 += steps
                                t8 = (rd.random()-1)*10
                                
                                x_g.append(np.array([t, t3, t2, t4]))
                                x_p_1.append(np.array([t, t3, t7, t4, t8, t2, t5]))
                                if w[2]*t2 < a*(w[1]*t+w[3]*t3+w[4]*t4+w[5]*t5+w[6]*t6+w[7]*t7):
                                    y.append(1.0)
                                else:
                                    y.append(0.0)
                                    #x_p_1.append(np.array([t, t3, t12, t11, t6, t4, t8, t7, t2, t5]))
                                    #y.append(0.0)
                                    #x_p_1.append(np.array([t, t3, t12, t11, t6, t4, t8, t7, t2, t5]))
                                    #y.append(0.0)
                            t7 = 0
                        t6 = 0
                    t5 = 0
                t4 = 0
            t3 = 0  
        t2 = 0
    return x_g, x_p_1, y

def experimental_distribution(A, b, num, w):
    x_g = []
    x_p_1 = []
    x_p_2 = []
    y = []
    steps = 10/num
    t = -5-steps
    t2 = -5-steps
    t3 = -5-steps
    t4 = -5-steps
    t5 = -5-steps
    t6 = -5-steps
    t7 = -5-steps

    if b != 'c':
        for e in range(num+1):
            t += steps
            for i in range(num+1):
                t2 += steps
                for j in range(num+1):
                    t3 += steps
                    for jj in range(num+1):
                        t4 += steps
                        for jjj in range(num+1):
                            t5 += steps
                            for jjjj in range(num+1):
                                t6 = t6+steps
                                for jjjjj in range(num+1):
                                    t7 += steps
                                    t8 = (rd.random()-1)*10
                                
                                    x_g.append(np.array([t, t3, t2, t4]))
                                    x_p_1.append(np.array([t, t3, t8, t2, t5, t4, t6]))
                                    if b < 180:
                                        if A > 0.999999:
                                            if w[2]*t2 < A*(w[1]*t+w[3]*t3+w[4]*t4+w[5]*t5+w[6]*t6+w[7]*t7):
                                                y.append(1.0)
                                                #y.append(1.0)
                                                #y.append(1.0)
                                                #x_p_1.append(np.array([t, t3, t8, t2, t5, t4, t6, t9, t12]))
                                                #x_p_1.append(np.array([t, t3, t8, t2, t5, t4, t6, t9, t12]))
                                            else:
                                                y.append(0.0)
                                        elif A < 1:
                                            if w[2]*t2 > A*(w[1]*t+w[2]*t2+w[3]*t3+w[4]*t4+w[5]*t5+w[6]*t6+w[7]*t7):
                                                y.append(1.0)
                                                #y.append(1.0)
                                                #y.append(1.0)
                                                #x_p_1.append(np.array([t, t3, t8, t2, t5, t4, t6, t9, t12]))
                                                #x_p_1.append(np.array([t, t3, t8, t2, t5, t4, t6, t9, t12]))
                                            else:
                                                y.append(0.0)
                                    else:
                                        if A > 0.999999:
                                            if w[2]*t2 > A*(w[1]*t+w[2]*t2+w[3]*t3+w[4]*t4+w[5]*t5+w[6]*t6+w[7]*t7):
                                                y.append(1.0)
                                                #y.append(1.0)
                                                #y.append(1.0)
                                                #x_p_1.append(np.array([t, t3, t8, t2, t5, t4, t6, t9, t12]))
                                                #x_p_1.append(np.array([t, t3, t8, t2, t5, t4, t6, t9, t12]))
                                            else:
                                                y.append(0.0)
                                        elif A < 1:
                                            if w[2]*t2 < A*(w[1]*t+w[2]*t2+w[3]*t3+w[4]*t4+w[5]*t5+w[6]*t6+w[7]*t7):
                                                y.append(1.0)
                                                #y.append(1.0)
                                                #y.append(1.0)
                                                #x_p_1.append(np.array([t, t3, t8, t2, t5, t4, t6, t9, t12]))
                                                #x_p_1.append(np.array([t, t3, t8, t2, t5, t4, t6, t9, t12]))
                                            else:
                                                y.append(0.0)
                                t7 = 0
                            t6 = 0
                        t5 = 0
                    t4 = 0
                t3 = 0
            t2 = 0
        return x_g, x_p_1, y
    else:
        for i in range(num):
            t = rd.random()*10 
            t2 = rd.random()*10 
            if t < 5:
                y.append(1.0)
            else:
                y.append(0.0)
        return x_g, x_p_1, y

def generate_data(hidden_feature, k, i, w):
    # first no hidden feature
    dataset = []
    if hidden_feature is False:
        #x_m, y_m = datasets.make_circles(noise=0.05)
        #x_c, y_c = datasets.make_circles(noise=0.05)
        x_m_g, x_m_p1, y_m = linear_distribution(1, 1, 2, w)
        x_c_g, x_c_p1, y_c = experimental_distribution(k, i, 2, w)
        dataset1_common = []
        dataset1_glnn1 = []
        dataset1_glnn1_test = []
        dataset1_test_common = []
        dataset2_common = []
        dataset2_glnn1 = []
        dataset2_glnn1_test = []
        dataset2_test_common = []
        for i in range(len(x_m_g)):
            if rd.random() < 0.9:
                dataset1_common.append([x_m_g[i], y_m[i]])
                dataset2_common.append([x_c_g[i], y_c[i]])
                dataset1_glnn1.append([x_m_p1[i], x_m_g[i], y_m[i]])
                dataset2_glnn1.append([x_c_p1[i], x_c_g[i], y_c[i]])
            else:
                dataset1_test_common.append([x_m_g[i], y_m[i]])
                dataset2_test_common.append([x_c_g[i], y_c[i]])
                dataset1_glnn1_test.append([x_m_p1[i], x_m_g[i], y_m[i]])
                dataset2_glnn1_test.append([x_c_p1[i], x_c_g[i], y_c[i]])
        return [dataset1_common, dataset2_common, dataset1_test_common, dataset2_test_common, dataset1_glnn1, dataset1_glnn1_test, dataset2_glnn1, dataset2_glnn1_test]
    else:
        x_g, y_g = datasets.make_moons(noise=0.05)
        x_l_m, y_l_m = datasets.make_moons(noise=0.05)
        x_l_c, y_l_c = datasets.make_circles(noise=0.05)
        # dataset allocate
        dataset1 = []
        dataset1_test = []
        dataset2 = []
        dataset2_test = []
        for i in range(len(x_l_m)):
            if rd.random() < 0.8:
                dataset1.append([x_l_m[i], x_g[i], y_g[i]])
                dataset2.append([x_l_c[i], x_g[i], y_g[i]])
            else:
                dataset1_test.append([x_l_m[i], x_g[i], y_g[i]])
                dataset2_test.append([x_l_c[i], x_g[i], y_g[i]])
        return [dataset1, dataset2, dataset1_test, dataset2_test]


def test(k, i2, varience):
    w = [1]*9
    for i in range(len(w)):
        w[i] = (0.5*rd.random()-1)*varience
    hidden_feature = False
    dataset = generate_data(hidden_feature, k, i2, w)
    # set1
    train_set1 = dataset[0]
    train_sample1 = train_set1[0]
    train_glnn = dataset[4]
    # set2
    train_set2 = dataset[1]
    train2_glnn = dataset[6]
    # test_set1
    test_set1 = dataset[2]
    test_glnn = dataset[5]
    # test_set1
    test_set2 = dataset[3]
    test2_glnn = dataset[7]

    # none feature suit models
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    classifier1 = TestNet(len(train_sample1[0]), 1).to(device)
    classifier2 = TestNet(len(train_sample1[0]), 1).to(device)
    server_model = TestNet(len(train_sample1[0]), 1).to(device)
    fedavg1 = TestNet(len(train_sample1[0]), 1).to(device)
    fedavg2 = TestNet(len(train_sample1[0]), 1).to(device)
    net = Decoupling(len(train_sample1[0]), 1).to(device)
    net2 = Decoupling(len(train_sample1[0]), 1).to(device)
    fed_bn = DigitModel(len(train_sample1[0]), 1).to(device)
    fed_bn2 = DigitModel(len(train_sample1[0]), 1).to(device)
    
    # feature suit models
    glnn_net1 = InfoNeural(len(train_glnn[0][0]), len(train_glnn[0][1]), 1).to(device)
    glnn_net2 = InfoNeural(len(train2_glnn[0][0]), len(train2_glnn[0][1]), 1).to(device)
    partial_net1 = PartialNet(len(train_glnn[0][0]),1)
    partial_net2 = PartialNet(len(train2_glnn[0][0]),1)
    single_local1 = TestNet(len(train_glnn[0][0]),1)
    single_local2 = TestNet(len(train2_glnn[0][0]),1)

    # loss_fn
    loss_fn = nn.BCELoss()

    # optimizer for non feature suit model
    optimizer = torch.optim.SGD(classifier1.parameters(), lr=0.01)
    optimizer1 = torch.optim.SGD(classifier2.parameters(), lr=0.01)
    optimizer2 = torch.optim.SGD(net.parameters(), lr=0.01)
    optimizer3 = torch.optim.SGD(net2.parameters(), lr=0.01)
    optimizer_bn1 = torch.optim.SGD(fed_bn.parameters(), lr=0.01)
    optimizer_bn2 = torch.optim.SGD(fed_bn2.parameters(), lr=0.01)
    optimizer_avg1 = torch.optim.SGD(fedavg1.parameters(), lr=0.01)
    optimizer_avg2 = torch.optim.SGD(fedavg2.parameters(), lr=0.01)

    #optimizer for feature suit model
    optimizer_glnn1 = torch.optim.SGD(glnn_net1.parameters(), lr=0.01)
    optimizer_glnn2 = torch.optim.SGD(glnn_net2.parameters(), lr=0.01)
    optimizer_partial1 = torch.optim.SGD(partial_net1.parameters(), lr=0.01)
    optimizer_partial2 = torch.optim.SGD(partial_net2.parameters(), lr=0.01)
    optimizer_single_local1 = torch.optim.SGD(single_local1.parameters(), lr=0.01)
    optimizer_single_local2 = torch.optim.SGD(single_local2.parameters(), lr=0.01)


    # pre-set parameters
    echo = 100
    loss_avg = []
    loss_prox = []
    loss_decoupleing = []
    loss_bn_l = []
    loss_partial = []
    loss_glnn = []
    loss_local = []
    lowest_loss_decouple = 9999
    lowest_loss_GLNN = 9999
    lowest_loss_BN = 9999
    lowest_loss_partial = 9999
    lowest_loss_single = 9999
    lowest_loss_avg = 9999
    lowest_loss_prox = 9999
    b_size = 400
    best_L = 0
    best_Avg = 0
    best_BN = 0
    best_De = 0
    best_GLNN = 0
    best_P = 0
    
    for e in range(echo):
        loss_sum_decouple = 0
        loss_sum = 0
        loss_sum_glnn = 0
        loss_sum_partial = 0
        loss_sum_single = 0
        loss_sum_bn = 0
        loss_sum_avg = 0
        fed_bn.train()
        fed_bn2.train()
        data = DataLoader(train_set1, batch_size=b_size)
        for sample_, label_ in data:# 训练第一个数据集
            pred_avg = fedavg1(sample_)
            pred_class = classifier1(sample_)
            pred_decoupling = net(sample_)
            if len(sample_)==b_size:
                pred_bn = fed_bn(sample_)
            label_ = label_.unsqueeze(-1)
            loss = loss_fn(pred_class, label_)
            loss2 = loss_fn(pred_decoupling, label_)
            lossAvg = loss_fn(pred_avg, label_)
            if len(sample_)==b_size:
                loss_bn = loss_fn(pred_bn, label_)
                optimizer_bn1.zero_grad()
                loss_bn.backward()
                optimizer_bn1.step()
                loss_sum_bn += loss_bn.item()
            #########################we implement FedProx Here###########################
            # referring to https://github.com/IBM/FedMA/blob/4b586a5a22002dc955d025b890bc632daa3c01c7/main.py#L819
            if e > 1:
                w_diff = torch.tensor(0., device='cpu')
                for w, w_t in zip(server_model.parameters(), classifier1.parameters()):
                    w_diff += torch.pow(torch.norm(w - w_t), 2)
                loss += 0.01 / 2. * w_diff
            #############################################################################
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            optimizer2.zero_grad()
            loss2.backward()
            optimizer2.step()
            optimizer_avg1.zero_grad()
            lossAvg.backward()
            optimizer_avg1.step()
            
            loss_sum_decouple += loss2.item()
            loss_sum += loss.item()
            loss_sum_avg += lossAvg.item()
            

        data = DataLoader(train_set2, batch_size=b_size)
        for sample_, label_ in data:# 训练第二个数据集
            pred_avg = fedavg2(sample_)
            pred_class = classifier2(sample_)
            pred_decoupling = net2(sample_)
            label_ = label_.unsqueeze(-1)
            if len(sample_)==b_size:
                pred_bn = fed_bn2(sample_)
            loss3 = loss_fn(pred_decoupling, label_)
            loss = loss_fn(pred_class, label_)
            lossAvg = loss_fn(pred_avg, label_)
            if len(sample_)==b_size:
                loss_bn = loss_fn(pred_bn, label_)
                optimizer_bn2.zero_grad()
                loss_bn.backward()
                optimizer_bn2.step()
                loss_sum_bn += loss_bn.item()
            loss_sum_decouple += loss3.item()
            #########################we implement FedProx Here###########################
            # referring to https://github.com/IBM/FedMA/blob/4b586a5a22002dc955d025b890bc632daa3c01c7/main.py#L819
            if e > 1:
                w_diff = torch.tensor(0., device='cpu')
                for w, w_t in zip(server_model.parameters(), classifier2.parameters()):
                    w_diff += torch.pow(torch.norm(w - w_t), 2)
                loss += 0.01 / 2. * w_diff
            #############################################################################
            loss_sum += loss.item()
            loss_sum_avg += lossAvg.item()
            optimizer1.zero_grad()
            loss.backward()
            optimizer1.step()
            optimizer3.zero_grad()
            loss3.backward()
            optimizer3.step()
            optimizer_avg2.zero_grad()
            lossAvg.backward()
            optimizer_avg2.step()

        data = DataLoader(train_glnn, batch_size=b_size)
        for sample_p, sample_g, label_ in data:# 训练第一个数据集
            
            pred_single = single_local1(sample_p)
            pred_glnn = glnn_net1(sample_p,sample_g)
            pred_partial = partial_net1(sample_p)
            label_ = label_.unsqueeze(-1)
            loss_single = loss_fn(pred_single, label_)
            loss_glnn_ = loss_fn(pred_glnn, label_)
            loss_partial_ = loss_fn(pred_partial, label_)
            optimizer_single_local1.zero_grad()
            loss_single.backward()
            optimizer_single_local1.step()
            optimizer_partial1.zero_grad()
            loss_partial_.backward()
            optimizer_partial1.step()
            optimizer_glnn1.zero_grad()
            loss_glnn_.backward()
            optimizer_glnn1.step()
            
            loss_sum_glnn += loss_glnn_.item()
            loss_sum_partial += loss_partial_.item()
            loss_sum_single += loss_single.item()
            

        data = DataLoader(train2_glnn, batch_size=b_size)
        for sample_p, sample_g, label_ in data:# 训练第一个数据集
            
            pred_single = single_local2(sample_p)
            pred_glnn = glnn_net2(sample_p,sample_g)
            pred_partial = partial_net2(sample_p)
            label_ = label_.unsqueeze(-1)
            loss_single = loss_fn(pred_single, label_)
            loss_glnn_ = loss_fn(pred_glnn, label_)
            loss_partial_ = loss_fn(pred_partial, label_)
            optimizer_single_local2.zero_grad()
            loss_single.backward()
            optimizer_single_local2.step()
            optimizer_partial2.zero_grad()
            loss_partial_.backward()
            optimizer_partial2.step()
            optimizer_glnn2.zero_grad()
            loss_glnn_.backward()
            optimizer_glnn2.step()
            
            loss_sum_glnn += loss_glnn_.item()
            loss_sum_partial += loss_partial_.item()
            loss_sum_single += loss_single.item()

        loss_avg.append(loss_sum_avg/2)
        loss_prox.append(loss_sum/2)
        loss_decoupleing.append((loss_sum_decouple)/2)
        loss_bn_l.append(loss_sum_bn/2)
        loss_local.append(loss_sum_single/2)
        loss_partial.append(loss_sum_partial/2)
        loss_glnn.append(loss_sum_glnn/2)
        if loss_sum_avg/2 < lowest_loss_avg:
            lowest_loss_avg = loss_sum/2
        if loss_sum/2 < lowest_loss_prox:
            lowest_loss_prox = loss_sum/2
        if lowest_loss_decouple > (loss_sum_decouple)/2:
            lowest_loss_decouple = (loss_sum_decouple)/2
        if lowest_loss_BN > loss_sum_bn/2:
            lowest_loss_BN = loss_sum_bn/2
        if loss_sum_single/2 < lowest_loss_single:
            lowest_loss_single = loss_sum_single/2
        if lowest_loss_partial > (loss_sum_partial)/2:
            lowest_loss_partial = (loss_sum_partial)/2
        if lowest_loss_GLNN > loss_sum_glnn/2:
            lowest_loss_GLNN = loss_sum_glnn/2
        print(loss_sum/2, loss_sum_decouple/2, loss_sum_bn/2, loss_sum_single/2, loss_sum_partial/2, loss_sum_glnn/2, e)
        # 聚合操作
        # For FedPartial
        for l in range(2,3):
            weight = (partial_net1.get_weight(l) + partial_net2.get_weight(l))/2
            partial_net1.set_weight(l, weight)
            partial_net2.set_weight(l, weight)

        # Decoupling and FedBN and FedAvg and GLNN 
        for l in range(3):
            weight = (classifier1.get_weight(l) + classifier2.get_weight(l))/2
            classifier1.set_weight(l, weight)
            classifier2.set_weight(l, weight)
            server_model.set_weight(l, weight)
            weight = (fedavg1.get_weight(l) + fedavg2.get_weight(l))/2
            fedavg1.set_weight(l, weight)
            fedavg2.set_weight(l, weight)
            weight = (fed_bn.get_weight(l) + fed_bn2.get_weight(l))/2
            fed_bn.set_weight(l, weight)
            fed_bn2.set_weight(l, weight)
            weight = (net.get_weight(l) + net2.get_weight(l))/2
            net.set_weight(l, weight)
            net2.set_weight(l, weight)
            weight = (glnn_net1.get_weight(l)+glnn_net2.get_weight(l))/2
            glnn_net1.set_weight(l,weight)
            glnn_net2.set_weight(l,weight)


        '''
        correct_class = 0
        correct_class2 = 0
        correct_local = 0
        correct_local2 = 0
        correct_bn = 0
        correct_bn2 = 0
        correct_glnn = 0
        correct_glnn2 = 0
        correct_partial = 0
        correct_partial2 = 0
        correct_de = 0
        correct_de2 = 0 
        print("testing"+str(e))
        for i in range(len(test_set1)):
            
                
            sample_ = torch.tensor(test_set1[i][0], dtype=torch.float64)
            label_ = torch.tensor(test_set1[i][1], dtype=torch.float64)
            sample_2 = torch.tensor(test_set2[i][0], dtype=torch.float64)
            label_2 = torch.tensor(test_set2[i][1], dtype=torch.float64)
            sample_glnn1p = torch.tensor(test_glnn[i][0], dtype=torch.float64)
            sample_glnn1g = torch.tensor(test_glnn[i][1], dtype=torch.float64)
            label_glnn1 = torch.tensor(test_glnn[i][2], dtype=torch.float64)
            sample_glnn2p = torch.tensor(test2_glnn[i][0], dtype=torch.float64)
            sample_glnn2g = torch.tensor(test2_glnn[i][1], dtype=torch.float64)
            label_glnn2 = torch.tensor(test2_glnn[i][2], dtype=torch.float64)
            fed_bn.eval()
            fed_bn2.eval()
            pred_class1 = classifier1(sample_)
            pred_class2 = classifier2(sample_2)
            pred_decoupling = net(sample_)
            pred_decoupling2 = net2(sample_2)
            pred_bn = fed_bn(sample_.unsqueeze(0))
            pred_bn2 = fed_bn2(sample_2.unsqueeze(0))
            pred_partial = partial_net1(sample_glnn1p)
            pred_partial2 = partial_net2(sample_glnn2p)
            pred_glnn = glnn_net1(sample_glnn1p, sample_glnn1g)
            pred_glnn2 = glnn_net2(sample_glnn2p, sample_glnn2g)
            pred_local = single_local1(sample_glnn1p)
            pred_local2 = single_local2(sample_glnn2p)
            
            if (pred_class1 > 0.5 and 1 == label_) or (pred_class1 < 0.5 and 0 == label_):
                correct_class += 1
            if (pred_decoupling > 0.5 and 1 == label_) or (pred_decoupling < 0.5 and 0 == label_):
                correct_de += 1
            if (pred_bn > 0.5 and 1 == label_) or (pred_bn < 0.5 and 0 == label_):
                correct_bn += 1
            if (pred_local > 0.5 and 1 == label_glnn1) or (pred_local < 0.5 and 0 == label_glnn1):
                correct_local += 1
            if (pred_partial > 0.5 and 1 == label_glnn1) or (pred_partial < 0.5 and 0 == label_glnn1):
                correct_partial += 1
            if (pred_glnn > 0.5 and 1 == label_glnn1) or (pred_glnn < 0.5 and 0 == label_glnn1):
                correct_glnn += 1

            if (pred_class2 > 0.5 and 1 == label_2) or (pred_class2 < 0.5 and 0 == label_2):
                correct_class2 += 1
            if (pred_decoupling2 > 0.5 and 1 == label_2) or (pred_decoupling2 < 0.5 and 0 == label_2):
                correct_de2 += 1   
            if (pred_bn2 > 0.5 and 1 == label_2) or (pred_bn2 < 0.5 and 0 == label_2):
                correct_bn2 += 1 
            if (pred_local2 > 0.5 and 1 == label_glnn2) or (pred_local2 < 0.5 and 0 == label_glnn2):
                correct_local2 += 1
            if (pred_partial2 > 0.5 and 1 == label_glnn2) or (pred_partial2 < 0.5 and 0 == label_glnn2):
                correct_partial2 += 1
            if (pred_glnn2 > 0.5 and 1 == label_glnn2) or (pred_glnn2 < 0.5 and 0 == label_glnn2):
                correct_glnn2 += 1
        
        acc_Avg = (correct_class/len(test_set1)+correct_class2/len(test_set2))/2
        acc_decouping = (correct_local/len(test_set1)+correct_local2/len(test_set2))/2
        acc_BN = (correct_bn/len(test_set1)+correct_bn2/len(test_set2))/2
        acc_partial = correct_partial/len(test_glnn)+ correct_partial2/len(test2_glnn)
        acc_partial = acc_partial/2
        acc_local = correct_local/len(test_glnn)+ correct_local2/len(test2_glnn)
        acc_local = acc_local/2
        acc_glnn = correct_glnn/len(test_glnn)+ correct_glnn2/len(test2_glnn)
        acc_glnn = acc_glnn/2
        if best_Avg < acc_Avg:
            best_Avg = acc_Avg
        if best_De < acc_decouping:
            best_De = acc_decouping
        if best_BN < acc_BN:
            best_BN = acc_BN
        if best_GLNN < acc_glnn:
            best_GLNN = acc_glnn
        if best_P < acc_partial:
            best_P = acc_partial
        if best_L < acc_local:
            best_L = acc_local
        '''
    if i2 in [10, 60, 120, 180]:
        x = range(0, echo)
        f = open("Factorweight"+str(i2)+".csv", "w", newline="")
        writer = csv.writer(f)
        #writer.writerow(["Partial"])
        #writer.writerow(loss_partial)
        #writer.writerow(["Decoupling"])
        #writer.writerow(loss_decoupleing)
        #writer.writerow(["FedBN"])
        #writer.writerow(loss_bn_l)
        #writer.writerow(["Local"])
        #writer.writerow(loss_local)
        #writer.writerow(["GLNN"])
        #writer.writerow(loss_glnn)
        writer.writerow(["FedAvg"])
        writer.writerow(loss_avg)
        f.close
    #plt.plot(x, loss_avg)
    #plt.plot(x, loss_net1)
    #plt.plot(x, loss_net2)
    #plt.ylabel("loss")
    #plt.ylim(0, 1)
    #plt.xlabel(" rounds ")
    #plt.legend(labels)
    #plt.show()
    print(best_P,best_De, best_BN, best_GLNN, best_L, best_Avg)
    return lowest_loss_partial, lowest_loss_decouple, lowest_loss_BN, lowest_loss_GLNN, lowest_loss_single, lowest_loss_avg, lowest_loss_prox
    #return lowest_loss_avg


res = []
lowest_loss1 = []
lowest_loss2 = []
lowest_loss3 = []
res.append(["方差", "Partial", "Decoupling", "FedBN", "GLNN", "Local", "FedAvg", "FedProx"])
# res.append(["角度", "FedProx"])

for i in range(0,8):
        j = 135
        du = (2*np.pi)*(j/360)
        k = np.tan(du)
        print(i)
        varience = i
        lowest_loss_partial, lowest_loss_decouple, lowest_loss_BN, lowest_loss_GLNN, lowest_loss_single, lowest_loss_avg, lowest_loss_prox = test(k, i, varience)      
        res.append([i, lowest_loss_partial, lowest_loss_decouple, lowest_loss_BN, lowest_loss_GLNN, lowest_loss_single, lowest_loss_avg, lowest_loss_prox])
        #lowest_loss1.append(lowest_loss_P)
        #lowest_loss2.append(lowest_loss_De)
        #lowest_loss3.append(lowest_loss_BN)

f = open("resultFedProxFactorWeight.csv", "w", newline="")
writer = csv.writer(f)
writer.writerows(res)



