import torch
import torch.nn as nn
from torch.autograd import Variable as v
import numpy as np
from torch.utils.data import DataLoader

torch.set_default_tensor_type(torch.DoubleTensor)

class LogisticRegression(nn.Module):
    def __init__(self, input_dimension):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dimension, 2),
            nn.Softmax()
        )

    def forward(self, input_x):
        result = self.net(input_x)
        return result

    @staticmethod
    def data_format_conversion(data_row):
        data_row = np.array(data_row)
        data_input = torch.tensor(data_row, dtype=torch.float32)
        return data_input

    def learning_process(self, data_set):  # 所有的行，最后一列为label
        echo = 10
        optimizer = torch.optim.Adam(self.net.parameters(), lr=0.01)
        loss_fn = nn.BCELoss()
        for i in range(echo):
            sum_loss = 0
            count = 0
            data_batch = []
            label_batch = []

            data = DataLoader(self.global_data_set, batch_size=30)
            for data_batch, label_batch in data:
                pred = self.net(data_batch)
                
                
                # pred = torch.unsqueeze(pred,0)
                # print(pred.unsqueeze(0))
                #label = label.unsqueeze(0)
                # pred = pred.unsqueeze(0)
                #print(label)
                # print(pred)
                loss = loss_fn(pred, label_batch.unsqueeze(-1))
                sum_loss += loss
                optimizer.zero_grad()
                sum_loss.backward()
                # print(sum_loss)
                optimizer.step()
                count = 0
                data_batch = []
                label_batch = []

    def save_model(self, model_name):
        torch.save(self.net, "model/" + str(self.option) + "/" + model_name + ".model")

    def load_model(self, path):
        self.net = torch.load(path)





