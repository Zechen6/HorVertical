from cProfile import label
from pickletools import optimize
import torch
import torch.nn as nn
import numpy as np
from torch.autograd import Variable as v
import random as rd


class SampleMapper(nn.Module):
    def __init__(self, input_dimension, output_dimension):
        super().__init__()
        self.target_net = nn.Sequential(
            nn.Linear(input_dimension, input_dimension*4),
            #nn.Sigmoid(),
            #nn.Linear(output_dimension*input_dimension*64,output_dimension*input_dimension*64),
            nn.Sigmoid(),
            nn.Linear(input_dimension*4, output_dimension)
        )
        self.space_relationships_net = nn.Sequential(#nn.Sigmoid(),
            # nn.Linear(output_dimension, output_dimension*input_dimension*64),
            nn.Sigmoid(),
            nn.Linear(output_dimension, output_dimension*2),
            nn.Sigmoid(),
            nn.Linear(output_dimension*2, input_dimension))
        self.model_list = ['0','2','4']

    def forward(self, x):
        #optimizer = torch.optim.SGD(self.target_net.parameters(), lr=0.01)
        #loss_fn = nn.MSELoss()
        #result = self.target_net(x)
        #loss = loss_fn(result, label_target)
        #optimizer.zero_grad()
        #loss.backward()
        #optimizer.step()
        result = self.target_net(x)
        result = self.space_relationships_net(result)
        return result
    
    def train_target(self, x, label_target):
        optimizer = torch.optim.SGD(self.target_net.parameters(), lr=0.01)
        loss_fn = nn.MSELoss()
        sum_loss = 0
        #for i in range(len(label_target)): 
        result = self.target_net(x)
        loss = loss_fn(result, label_target)
        sum_loss += loss
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        # print("inner process")
        # print(sum_loss)

    @staticmethod
    def data_format_conversion(data_row):
        data_row = np.array(data_row)
        data_input = v(torch.tensor(data_row, dtype=torch.float32))
        return data_input


def data_format_conversion(data_row):
    data_row = np.array(data_row)
    data_input = v(torch.tensor(data_row, dtype=torch.float32))
    return data_input


def mapper_process(input_data_set, output_data_set, global_model, local_model, privacy_demand):  # 所有的行，最后一列为label
    input_dimension = len(input_data_set[0])-1
    output_dimension = len(output_data_set[0])-1
    get_best_output(privacy_demand, global_model, output_data_set, local_model, input_data_set)
    sample_mapper = SampleMapper(input_dimension, output_dimension)
    echo = 100
    optimizer = torch.optim.SGD(sample_mapper.parameters(), lr=0.01)
    loss_fn = nn.MSELoss()
    for i in range(echo):
        inner_label = data_format_conversion(output_data_set)
        for j in range(len(input_data_set)):
            input_features = sample_mapper.data_format_conversion(input_data_set[j][0:input_dimension])
            sample_mapper.train_target(input_features, inner_label[j][0:output_dimension])
            pred = sample_mapper(input_features)
            loss = loss_fn(pred, input_features)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
    new_data = []
    for data in input_data_set:
        data = data_format_conversion(data[0:input_dimension])
        new_data.append(torch.cat((sample_mapper.target_net(data), torch.tensor([data[-1]])),dim=0).detach().numpy())
    return new_data, sample_mapper


def get_label(input_data_set):
    space_relationships = [0] * len(input_data_set)
    for i in range(len(input_data_set)):
        for j in range(len(input_data_set)):
            space_relationships[i] += get_dis(input_data_set[i], input_data_set[j])
    return space_relationships


def get_dis(a, b):
    if len(a) != len(b):
        print("dimension error")
    dis = 0
    for i in range(len(a)):
        dis += (a[i]-b[i])*(a[i]-b[i])
    return dis


def get_best_output(privacy_demand, global_model, output_data_set, local_model, input_data_set):
    echo = 10
    c = 0
    for data in output_data_set:
        if data[-1] == 1:
            index = 0
        else:
            index = 1
        for j in range(echo):
            pred_o = global_model(data_format_conversion([data[0:len(data)-1]]))
            #pred_l = local_model(data_format_conversion([input_data_set[c][0:len(input_data_set[c])-1]]))
            temp_data = [0]*len(data)
            temp_data[-1] = data[-1]
            for i in range(len(data)-1):
                temp_data[i] = data[i] + rd.uniform(-privacy_demand, privacy_demand)/(j+1)
            pred_o2 = global_model(data_format_conversion([temp_data[0:len(data)-1]]))
            if pred_o2.detach().numpy()[0][index] > pred_o.detach().numpy()[0][index]:
                for i in range(len(data)):
                        data[i] = temp_data[i]
            '''
            if pred_l.detach().numpy()[0][0] >= pred_l.detach().numpy()[0][1] and pred_o.detach().numpy()[0][0] >= pred_o.detach().numpy()[0][1]:
                if pred_o2.detach().numpy()[0][index] < pred_o.detach().numpy()[0][index]:
                    
            else:
                if pred_o2.detach().numpy()[0][index] > pred_o.detach().numpy()[0][index]:
                    for i in range(len(data)):
                        data[i] = temp_data[i]
            '''
        c = c + 1


def test():
    model = SampleMapper(16, 6)
    input_data = []
    label_data1 = []
    label_data2 = []
    for i in range(1, 101):
        input_data.append((torch.rand(1,16)*0.11111-np.log(i)/80))
        label_data1.append((torch.rand(1,6)*0.11111+np.log(i))/80)
        label_data2.append(input_data[i-1])
    optimizer = torch.optim.SGD(model.parameters(), lr=0.01)
    loss_fn = nn.MSELoss()
    echo = 300
    
    for i in range(echo):
        sum_loss = 0
        
        for j in range(len(input_data)):
            model.train_target(input_data[j], label_data1[j])
            
            #pred = model(input_data[j])
            #loss = loss_fn(pred, label_data2[j])
            #optimizer.zero_grad()
            #loss.backward()
            #optimizer.step()
            #sum_loss += loss
        # print(sum_loss)
    for l in range(len(input_data)):
        print(label_data1[l].detach().numpy())
        print(model.target_net(input_data[l]))
        print("-------------------")    
    


    

test()
