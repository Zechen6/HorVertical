from torch import device
from LocalModel.LocalModel import LocalModel
from CVSOperator import CSVOperator
# from sample_mapper import mapper_process
# from sample_mapper import SampleMapper
from GlobalModel.client  import ClientGlobal
import numpy as np
import random as rd
import torch
import time
from torch.utils.data import DataLoader

torch.set_default_tensor_type(torch.DoubleTensor)

class Client:
    def __init__(self, data_set, model_type, ID, model_path):
        self.client_id = ID
        self.path = data_set
        self.model_path = model_path
        self.global_feature = [0, 1, 14, 6, 2, 12, 18]
        self.csv_operator = CSVOperator(data_set, 'r')
        self.data_set, self.global_data_set, self.data_set_test, self.global_data_set_test = self.load_data()
        self.local_model = LocalModel(model_type, len(self.data_set[0])-1)
        self.global_model = ClientGlobal(ID, len(self.global_feature)-1, 1)
        self.global_model.database = self.global_data_set
        self.original_global_dataset = self.global_data_set_test
        self.time_cost = 0
        self.len_global = len(self.global_feature)-1
        self.len_local = len(self.data_set[0])-1
        self.base = self.len_global/self.len_local
        
        self.privacy_demand = rd.random()*0.2
    
    def train_local_model(self):
        self.local_model.model.learning_process(self.data_set)

    def save_model(self):
        self.local_model.save_model(self.client_id)


    def test(self, e):
        row = []
        title = ["+", "-", "groundtrueth"]
        time_cost_start = time.time()
        row.append(title)
        c = 0
        for data in self.global_data_set_test:
            input_data = data_format_conversion([data[1:self.len_global+1]])
            #global_data = self.sample_mapper.target_net(input_data)
            global_res = self.global_model.network(input_data)

            res = global_res.detach().numpy()
            row.append([res[0], 1-res[0], data[0]])
        time_cost_end = time.time()
        self.time_cost = time_cost_end-time_cost_start
        csv_writer = CSVOperator("result/diabetes/"+ str(e) +"/"+self.model_path, 'w')
        csv_writer.write_row(row)
            
            

    def load_data(self):
        data_set_train = []
        global_data_set_train = []
        data_set_test = []
        global_data_set_test = []
        c = 0
        data_set_all = []
        for row in self.csv_operator.reader:
            if c == 0:
                c += 1
                continue
            data_set_all.append(row)
        rd.seed(self.client_id)
        rd.shuffle(data_set_all)
        for row in data_set_all:
            data_temp = []
            global_data_temp = []
            for i in range(len(row)):
                if row[i] != '-':
                    data_temp.append(float(str(row[i])))
                    if i in self.global_feature:
                        global_data_temp.append(float(str(row[i])))
            
            #data_temp.append(float(str(row[0])))
            #global_data_temp.append(float(str(row[0])))
            #if data_temp[-1] == 1 and rd.random()>0.4:
            #    data_set_train.append(np.array(data_temp))
            #    global_data_set_train.append(np.array(global_data_temp))
            if c < np.floor(len(data_set_all)*0.7):
                data_set_train.append(np.array(data_temp))
                global_data_set_train.append(np.array(global_data_temp))
                
            else:
                data_set_test.append(np.array(data_temp))
                global_data_set_test.append(np.array(global_data_temp))
            c += 1
        res_train = []
        for data in global_data_set_train:
            sample = data[1:len(data)]
            res_train.append([sample, data[0]])
        return res_train, res_train, data_set_test, global_data_set_test
        # return data_set_train, global_data_set_train, data_set_test, global_data_set_test


def data_format_conversion(data_row):
        data_row = np.array(data_row)
        data_input = torch.tensor(data_row, dtype=torch.float64)
        return data_input