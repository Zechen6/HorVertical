from cmath import inf
from CVSOperator import CSVOperator
import os
import random as rd
import time
import numpy as np
data_file = "dataset\\医疗预约却没有赴约-较好\\KaggleV2-sorted.csv"
out_data_document = "dataset\\医疗预约却没有赴约-较好\\pre_operate\\"


def step1():
    csv_reader = CSVOperator(data_file, 'r')
    c = 0
    old_patient_id = 0
    patient_rows = []
    neighbours = []
    # step_1 将所有记录按照病人分类
    for row in csv_reader.reader:
        if c == 0:
            title = [row]
            c = 1
            continue
        patient_id = int(float(str(row[0])))
        gender = str(row[2])
        scheduled_day = str(row[3]).replace("T"," ")
        appointment_day = str(row[4]).replace("T", " ")
        appointment_day = appointment_day.replace("Z", "")
        appointment_day = time.strptime(appointment_day, "%Y-%m-%d %H:%M:%S")
        scheduled_day = scheduled_day.replace("Z","")
        scheduled_day = time.strptime(scheduled_day, "%Y-%m-%d %H:%M:%S")
        row[3] = int(time.mktime(scheduled_day))
        row[4] = int(time.mktime(appointment_day))
        if str(row[-1]) == 'Yes':
            row[-1] = 1
        else:
            row[-1] = -1
        if gender == 'M':
            row[2] = 1
        else:
            row[2] = 0
        if str(row[6]) not in neighbours:
            neighbours.append(str(row[6]))
        for i in range(len(neighbours)):
            if str(row[6]) == neighbours[i]:
                row[6] = i
        if patient_id == old_patient_id:
            patient_rows.append(row)
        else:
            if old_patient_id != 0 and len(patient_rows) > 6:
                csv_writer = CSVOperator(out_data_document+"\\step1\\"+str(patient_id)+".csv", 'w')
                csv_writer.write_row(title)
                csv_writer.write_row(patient_rows)
                csv_writer.end()
            old_patient_id = patient_id
            patient_rows.clear()
            patient_rows.append(row)


def step2():
    # 随机删除特征
    in_path = out_data_document + "\\step1\\"
    out_path = out_data_document + "\\step2\\"
    data_sets = os.listdir(out_data_document + "\\step1")
    global_feature = [0, 2, 12, 3, 4, 5, 13]
    local_feature = [1, 6, 7, 8, 9, 10, 11]
    for data_set in data_sets:
        csv_reader = CSVOperator(in_path+data_set, 'r')
        c = 0
        csv_writer = CSVOperator(out_data_document + "\\step2\\" + data_set, 'w')
        local_feature_num = rd.randint(2, len(local_feature))
        rd.shuffle(local_feature)
        for row in csv_reader.reader:
            if c == 0:
                title = [row]
                csv_writer.write_row(title)
                c = 1
                continue
            for i in range(local_feature_num):
                row[local_feature[i]] = "-"
            csv_writer.write_row([row])
        csv_writer.end()

def step3():
    #正则化
    in_path = out_data_document + "\\step2\\"
    out_path = out_data_document + "\\step3\\"
    data_sets = os.listdir(out_data_document + "\\step2")
    for data_set in data_sets:
        csv_reader = CSVOperator(in_path+data_set, 'r')
        c = 0
        csv_writer = CSVOperator(out_data_document + "\\step3\\" + data_set, 'w')
        row_count, col_count= csv_reader.get_row_count()
        csv_reader.end()
        csv_reader = CSVOperator(in_path+data_set, 'r')
        features = [[0 for i in range(row_count-1)] for j in range(col_count)]
        new_rows = [[0 for i in range(col_count)] for j in range(row_count-1)]
        for row in csv_reader.reader:
            if c == 0:
                title = [row]
                csv_writer.write_row(title)
                c = 1
                continue
            for i in range(len(row)):
                if str(row[i]) == "-":
                    continue
                else:
                    if i == 5:
                        features[i][c-1] = float(str(row[i]))/100
                    elif i == 6:
                        features[i][c-1] = float(str(row[i]))/100
                    else:
                        features[i][c-1] = float(str(row[i]))
                    
            c += 1
        
        for i in range(len(features)):
            for j in range(len(features[i])):
                if isinstance(features[i][j],float):
                    if i == 5 or i == 6 or i == 13:
                        new_rows[j][i] = features[i][j]
                        continue
                    if np.max(features[i]) != 0:
                        new_rows[j][i] = features[i][j] / abs(np.max(features[i]))
        csv_writer.write_row(new_rows)
        csv_reader.end()
        csv_writer.end()

def run():
    step1()
    step2()
    step3()
    return 0


