from operator import mod
from pickletools import optimize
import torch
import torch.nn as nn
import numpy as np
from torch.autograd import Variable as v
import random as rd

class SampleMapper(nn.Module):
    def __init__(self, input_dimension, output_dimension):
        super().__init__()
        self.target_net = nn.Sequential(
            nn.Linear(input_dimension, output_dimension*input_dimension*2),
            nn.Sigmoid(),
            #nn.Linear(output_dimension*input_dimension*64,output_dimension*input_dimension*64),
            #nn.Sigmoid(),
            nn.Linear(output_dimension*input_dimension*2, output_dimension)
        )
        self.space_relationships_net = nn.Sequential(nn.Sigmoid(),
            # nn.Linear(output_dimension, output_dimension*input_dimension*64),
            # nn.Tanh(),
            # nn.Linear(output_dimension*input_dimension*64, input_dimension))
            nn.Linear(output_dimension, input_dimension))
        self.model_list = ['0','2','4']

    def forward(self, x):
        #optimizer = torch.optim.SGD(self.target_net.parameters(), lr=0.01)
        #loss_fn = nn.MSELoss()
        #result = self.target_net(x)
        #loss = loss_fn(result, label_target)
        #optimizer.zero_grad()
        #loss.backward()
        #optimizer.step()
        result = self.target_net(x)
        result = self.space_relationships_net(result)
        return result
    
def test():
    x = [0]*100
    for i in range(len(x)):
        x[i] = np.sin(i*0.01)
    model = SampleMapper(1,1)
    optimizer = torch.optim.SGD(model.parameters(), lr=0.01)
    loss_fn = nn.MSELoss()
    echo = 100
    for i in range(echo):
        for j in range(100):
            pred = model(torch.tensor([j],dtype=torch.float32))
            label = torch.tensor([x[j]], dtype=torch.float32)
            loss = loss_fn(pred, label)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
    for i in range(100):
        print(x[i])
        print(model(torch.tensor([i], dtype=torch.float32)))

test()
