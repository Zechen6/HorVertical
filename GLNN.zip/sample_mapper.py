from cProfile import label
from cmath import nan
from pickletools import optimize
from tkinter import W
from tokenize import Double
import torch
import torch.nn as nn
import numpy as np
from torch.autograd import Variable as v
import random as rd
import time

class SampleMapper(nn.Module):
    def __init__(self, input_dimension, output_dimension):
        super().__init__()
        self.target_net = nn.Sequential(
            nn.Linear(input_dimension, input_dimension*4),
            #nn.Sigmoid(),
            #nn.Linear(output_dimension*input_dimension*64,output_dimension*input_dimension*64),
            nn.Sigmoid(),
            nn.Linear(input_dimension*4, output_dimension*2),
            nn.Sigmoid(),
            nn.Linear(output_dimension*2, output_dimension)
        )
        self.space_relationships_net = nn.Sequential(nn.Sigmoid(),
            #nn.Linear(output_dimension, output_dimension*2),
            #nn.Sigmoid(),
            # nn.Linear(output_dimension*input_dimension*64, input_dimension))
            nn.Linear(output_dimension, input_dimension))
        self.model_list = ['0','2','4']
        self.last_result = []
        self.last_t_result = []

    def forward(self, x):
        #optimizer = torch.optim.SGD(self.target_net.parameters(), lr=0.01)
        #loss_fn = nn.MSELoss()
        #result = self.target_net(x)
        #loss = loss_fn(result, label_target)
        #optimizer.zero_grad()
        #loss.backward()
        #optimizer.step()
        result = self.target_net(x)
        result = self.space_relationships_net(result)
        return result
    
    def clip_weight(self, weight):
        data = weight.data.detach().numpy()
        for i in range(len(data)):
            data[i] = [min(max(x, 1.0000001),0) for x in data[i]]
        weight.data = torch.tensor(data)
        return weight
    
    def clip_expect(self, weight):
        data = weight.data.detach().numpy()
        for i in range(len(data)):
            data[i] = [min(max(x, 1.0000001),-1) for x in data[i]]
        weight.data = torch.tensor(data)
        return weight

    def train_target(self, x, label_target, global_model, s):

        optimizer = torch.optim.SGD(self.target_net.parameters(), lr=0.01)
        loss_fn1 = nn.CrossEntropyLoss()
        loss_fn2 = nn.MSELoss()
        sum_loss = 0
        act_fn = nn.Sigmoid()
        softmax_fn = nn.Softmax()
        echo = 100
        result = self.target_net(x)
        pred = global_model(result)
        pred = pred.unsqueeze(0)
        if s == 0:
            label = torch.tensor([[1,0]],dtype=torch.float32)
        else:
            label = torch.tensor([[0,1]],dtype=torch.float32) 
        
        y = result
        flag=False
        count = 0
        cn = 0
        for item in self.last_result:
            if item.equal(result):
                flag = True
                result = self.last_t_result[count]
                self.last_result.pop(count)
            count += 1
        self.last_result.append(result)
        rtarget_result = result
        loss_last = 100
        for i in range(echo):
            if flag:
                break
            '''
            for j in range(len(global_model.classification)):
                y = global_model.classification[j](y)
                if j == 0:
                    w_in = y.unsqueeze(0)
                if j == 1:
                    out1 = y
                if j == 3:
                    out2 = y
                if j == 4:
                    out3 = y
            label_p = y.unsqueeze(0)
            #out1 = torch.mm(global_model.get_weight(0), result.detach().numpy())
            #out2 = torch.mm(global_model.get_weight(1), act_fn(out1))
            #label_p = torch.mm(global_model.get_weight(2), act_fn(out2))
            #label_p = softmax_fn(label_p).unsqueeze(0)
            # pred.grad_fn = result.grad_fn
            loss = loss_fn1(label_p, label)
            #if loss >= loss_last:
            #    mu = -0.0007
            #else:
            #    loss_last = loss
            #    mu = 0.0005
            if loss < 0.654:
                 result = rtarget_result
                 break
            # print(loss)
            mu = 0.05
            ds_df = label-out3 # 1*2 第三层期望输出
            # f = f.T
            df_dg = global_model.get_weight(2) #2*24
            f = torch.matmul(df_dg,act_fn(out2))#得到第三层的原本输出
            #第三层的误差：
            e_3 = ds_df-f
            # out2_expect = out2 + torch.matmul(e_3, df_dg) #得到第二层sig后的期望输出
            e_s_2 = torch.matmul(e_3, df_dg) # 得到第二层sig后的误差,也就是
            out2_expect = act_fn(out2) + e_s_2*mu
            #第二层sig前的期望输出为:
            out1_expect = self.clip_expect(out2_expect)
            out2_expect = -torch.log(1+out2_expect/(1-out2_expect))*0.5
            #第二层sig前的误差
            e_2 = out2_expect-out2
            #第一层sig后的误差
            e_s_1 = torch.matmul(e_2, global_model.get_weight(1))*mu
            #第一层sig后期望输出
            out1_expect = e_s_1 + act_fn(out1)
            #第一层sig前期望输出
            out1_expect = self.clip_expect(out1_expect)
            out1_expect = -torch.log(1+out1_expect/(1-out1_expect))*0.5
            #第一层误差
            e_1 = out1_expect - out1
            #期望输入：
            e_in = torch.matmul(e_1, global_model.get_weight(0))
            rtarget_result = rtarget_result + e_in*mu
            cn += 1
            if cn>20 and loss>0.7:
                data_t = rtarget_result.detach().numpy()
                for i in range(len(data_t[0])):
                    if i != 5 and i != 4:
                        data_t[0][i] = rd.randint(0,1)
                    data_t[0][i] = rd.uniform(0,1)
                rtarget_result = torch.tensor(data_t)
                y = rtarget_result.squeeze(0)
                cn = 0
                continue

            


            #a = act_fn(out2).detach().numpy()
            #for item in a:
            #    item = item*(1-item)
            #tem = torch.tensor(a).unsqueeze(0)
            #dg_dh = torch.matmul(tem, global_model.get_weight(1)).T # 24*24
            #dh_dwx 
            #a = act_fn(out1).detach().numpy()
            #for item in a:
            #    item = item*(1-item)
            #tem = torch.tensor(a).unsqueeze(0)
            #dh_dwx = tem
            #dwx_dx = global_model.get_weight(0)
            #r1 = torch.matmul(f, dg_dh)
            #r2 = torch.matmul(r1, dh_dwx)
            #r3 = torch.matmul(r2, dwx_dx)
            
            # h = torch.matmul(w_in*(torch.ones_like(w_in)-w_in).T, w) # 24*4
            # h = h.T # 24*6
            # h = torch.mm(torch.mm(act_fn(out1), (-act_fn(out1))), global_model.get_weight(0))
            
            #target_result = loss.detach().numpy()*torch.matmul(torch.matmul(act_fn(out1)*(torch.ones_like(out1)-act_fn(out1)),act_fn(out2)*(torch.ones_like(out2)-act_fn(out2))),global_model.get_weight(2)*(label-label_p))
            #r3 = r3.detach().numpy()
            #for ii in range(len(r3[0])):
            #    a = rd.uniform(-mu, mu)
            #    r3[0][ii] = a*r3[0][ii]
            #rtarget_result = torch.tensor(r3)
            #norm2 = torch.matmul(target_result, target_result.T)
            # result = (rtarget_result) + result
            y = rtarget_result.squeeze(0)
        '''
        # rtarget_result = torch.tensor(result)
        self.last_t_result.append(rtarget_result)

        echo = 5
        for i in range(echo): 
            result = self.target_net(x)
            rtarget_result = torch.tensor(rtarget_result)
            loss = loss_fn2(result, rtarget_result)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            if loss < 0.00001:
                return
        # print("inner process")
            #print(loss)
        #print("-----------------------")

    @staticmethod
    def data_format_conversion(data_row):
        data_row = np.array(data_row)
        data_input = v(torch.tensor(data_row, dtype=torch.float32))
        return data_input


def data_format_conversion(data_row):
    data_row = np.array(data_row)
    data_input = v(torch.tensor(data_row, dtype=torch.float32))
    return data_input


def mapper_process(input_data_set, output_data_set, global_model, local_model, privacy_demand):  # 所有的行，最后一列为label
    input_dimension = len(input_data_set[0])-1
    output_dimension = len(output_data_set[0])-1
    # get_best_output(privacy_demand, global_model, output_data_set, local_model, input_data_set)
    sample_mapper = SampleMapper(input_dimension, output_dimension)
    echo = 1
    optimizer = torch.optim.SGD(sample_mapper.parameters(), lr=0.01)
    loss_fn = nn.MSELoss()
    for i in range(echo):
        inner_label = data_format_conversion(output_data_set)
        for j in range(len(input_data_set)):
            input_features = sample_mapper.data_format_conversion(input_data_set[j][0:input_dimension])
            sample_mapper.train_target(input_features, inner_label[j][0:output_dimension], global_model, input_data_set[j][-1])
            pred = sample_mapper(input_features)
            loss = loss_fn(pred, input_features)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
    new_data = []
    for data in input_data_set:
        data = data_format_conversion(data[0:input_dimension])
        new_data.append(torch.cat((sample_mapper.target_net(data), torch.tensor([data[-1]])),dim=0).detach().numpy())
    return new_data, sample_mapper


def get_label(input_data_set):
    space_relationships = [0] * len(input_data_set)
    for i in range(len(input_data_set)):
        for j in range(len(input_data_set)):
            space_relationships[i] += get_dis(input_data_set[i], input_data_set[j])
    return space_relationships


def get_dis(a, b):
    if len(a) != len(b):
        print("dimension error")
    dis = 0
    for i in range(len(a)):
        dis += (a[i]-b[i])*(a[i]-b[i])
    return dis


def get_best_output(privacy_demand, global_model, output_data_set, local_model, input_data_set):
    echo = 10
    c = 0
    data_len = len(output_data_set[0])-1
    move_p = [0] * (data_len + 1)
    p = 0
    n = 0
    move_n = [0] * (data_len + 1)
    stop = 0
    start_time = time.time()
    while stop == 0:
        for data in output_data_set:
            if data[-1] == 0:
                index = 0
                if p == 1:
                    for i in range(len(data)):
                        data[i] = move_p[i] + data[i]
                    continue
            else:
                index = 1
                if n == 1:
                    for i in range(len(data)):
                        data[i] = move_n[i] + data[i]
                    continue
            
            for j in range(echo):
                pred_o = global_model(data_format_conversion([data[0:data_len]]))
                #pred_l = local_model(data_format_conversion([input_data_set[c][0:len(input_data_set[c])-1]]))
                temp_data = [0]*len(data)
                temp_data[-1] = data[-1]
                for i in range(len(data)-1):
                    if index == 1:
                        move_n[i] = rd.uniform(-privacy_demand, privacy_demand)
                        temp_data[i] = data[i] + move_n[i]
                    else:
                        move_p[i] = rd.uniform(-privacy_demand, privacy_demand)
                        temp_data[i] = data[i] + move_p[i]
                        
                pred_o2 = global_model(data_format_conversion([temp_data[0:data_len]]))
                after_search = pred_o2.detach().numpy()[0][index]
                origin = pred_o.detach().numpy()[0][index]
                if after_search > 0.8:
                    stop = 1
                    p = 0
                    n = 0
                    break
                if after_search > 0.5 or origin > 0.5:
                    stop = 1

                if after_search>origin :
                    if index == 0:
                        p = 1
                    for i in range(len(data)):
                            move_p[i] = temp_data[i] - data[i]
                            data[i] = move_p[i] + data[i]
                    else:
                        # n = 1
                        for i in range(len(data)):
                            data[i] = temp_data[i]
                            # move_n[i] = np.add(temp_data[i], -data[i])
                            # data[i] = move_n[i] + data[i]
            '''
            if pred_l.detach().numpy()[0][0] >= pred_l.detach().numpy()[0][1] and pred_o.detach().numpy()[0][0] >= pred_o.detach().numpy()[0][1]:
                if pred_o2.detach().numpy()[0][index] < pred_o.detach().numpy()[0][index]:
                    
            else:
                if pred_o2.detach().numpy()[0][index] > pred_o.detach().numpy()[0][index]:
                    for i in range(len(data)):
                        data[i] = temp_data[i]
            '''
        c = c + 1
    end_time = time.time()
    print(end_time-start_time)

def test():
    model = SampleMapper(16, 6)
    input_data = []
    label_data1 = []
    label_data2 = []
    for i in range(1, 101):
        input_data.append((torch.rand(1,16)*2+np.log(i))/100)
        label_data1.append((torch.rand(1,6)*2+np.log(i))/100)
        label_data2.append(input_data[i-1])
    optimizer = torch.optim.SGD(model.parameters(), lr=0.01)
    loss_fn = nn.MSELoss()
    echo = 200
    
    for i in range(echo):
        sum_loss = 0
        
        
        for j in range(len(input_data)):
            model.train_target(input_data[j], label_data1[j])
            pred = model(input_data[j])
            loss = loss_fn(pred, label_data2[j])
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            sum_loss += loss
        # print(sum_loss)
        
    for i in range(len(input_data)):
        print(label_data1[i].detach().numpy())
        print(model.target_net(input_data[i]))
        print("-------------------")


    

# test()
