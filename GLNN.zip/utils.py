from turtle import forward
import numpy as np
import torch
import torch.nn as nn

class NeuralNetwork(nn.Module):
    def __init__(self, input_dimension, output_dimension) -> None:
        super().__init__()
        self.classification = nn.Sequential(
            nn.Linear(input_dimension, 4*input_dimension),
            nn.Sigmoid(),
            nn.Linear(4*input_dimension, 4*input_dimension),
            nn.Sigmoid(),
            nn.Linear(4*input_dimension, output_dimension)
        )

    def forward(self,x):
        return self.classification(x)

def act_derivative(x, act):
    if act == 'sig':
        sig = nn.Sigmoid()
        return sig(x)*(1-sig(x))
    elif act == 'Tanh':
        tanh = nn.Tanh()
        return 2*torch.pow(tanh(x), 3) - 2*tanh(x)
    return torch.ones_like(x)
    

def MSE_derivative(x, x_t):
    return x_t-x

def neural_derivative_w(in_put):
    return in_put

def neural_derivative_in(w):
    return w

class DerivativeChain():
    def __init__(self, model) -> None:
        self.model = model
    
    def derivative(self, x, layer, y_t, act):
        in_ = x
        temp = []
        temp.append(in_)
        for i in range(len(self.model)):
            x = self.model[i](x)
            temp.append(x)
        diff_chain = []
        for i in range(len(temp)-1, layer-1, -1):
            if i == len(temp)-1:
                diff_chain.append(MSE_derivative(temp[i], y_t))
                continue
            if i == layer-1:
                if i % 2 == 0:
                    diff_chain.append(neural_derivative_in(self.model[i].weight.data))
                    continue
                if i % 2 == 1:
                    diff_chain.append(neural_derivative_w(temp[i]))
                    continue
            if i % 2 == 1:
                diff_chain.append(act_derivative(temp[i], act))
                continue
            if i % 2 == 0:
                diff_chain.append(neural_derivative_in(self.model[i].weight.data))
                continue
        result = torch.tensor(1, dtype=torch.float32).unsqueeze(0)
        for i in range(len(diff_chain)):
            result = torch.matmul(result, diff_chain[i])
            print(result.shape)
        return result
            
def test():
    model = NeuralNetwork(4, 6)
    diff_chain = DerivativeChain(model.classification)
    input_data = []
    label_data1 = []
    label_data2 = []
    for i in range(1, 101):
        input_data.append((torch.rand(1,4)*2+np.log(i))/100)
        label_data1.append((torch.rand(1,6)*2+np.log(i))/100)
        label_data2.append(input_data[i-1])
    diff = diff_chain.derivative(input_data[0], 0, label_data1[0], 'sig')
    print(diff)

test()