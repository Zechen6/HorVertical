import data_organization.appointment as appointment


appointment.run()

