from enum import Flag
from torch import device
#from LocalModel.LocalModel import LocalModel
from CVSOperator import CSVOperator
from LocalModel.InfoNeural import InfoNeural
#from sample_mapper import mapper_process
#from sample_mapper import SampleMapper
#from GlobalModel.client  import ClientGlobal
import numpy as np
import random as rd
import torch
import time
import torch.nn as nn
from GlobalModel.neural_net_work import NeuralNetWork

def CrossEntropy_derivative(pred, label):
    if pred == 0:
        pred = 0.00001
    pred = (1/pred)*label - (1-label)/(1-pred)
    return -pred

class Client:
    def __init__(self, data_set, model_type, ID, model_path):
        self.client_id = ID
        self.path = data_set
        self.model_path = model_path
        self.global_feature = [0, 1, 14, 6, 2, 12, 18]
        self.csv_operator = CSVOperator(data_set, 'r')
        self.data_set, self.global_data_set, self.data_set_test, self.global_data_set_test = self.load_data()
        # self.sample_mapper = SampleMapper(len(self.data_set[0])-1, len(self.global_data_set[0])-1)
        self.sample_mapper = 0
        #self.local_model = LocalModel(model_type, len(self.data_set[0])-1)
        self.model = NeuralNetWork(len(self.data_set[0])-1, 1)
        #self.global_model = ClientGlobal(ID, len(self.global_feature)-1, 2)
        #self.global_model.database = self.global_data_set
        self.original_global_dataset = self.global_data_set_test
        self.time_cost = 0
        self.len_global = len(self.global_feature)-1
        self.len_local = len(self.data_set[0])-1
        self.base = self.len_global/self.len_local
        
        #self.privacy_demand = max(min(rd.random(), 0.3),1)
    
    def train_local_model(self):
        self.local_model.model.learning_process(self.data_set)

    def save_model(self):
        self.local_model.save_model(self.client_id)
    
    def training_process(self):
        echo = 10
        loss_sum = 0
        loss_fn = nn.BCELoss()
        opimizer = torch.optim.SGD(self.model.parameters(), lr=0.01)
        flag = False
        for e in range(echo):
            # print(e)
            count = 0
            data_batch = []
            data_g_batch = []
            label_batch = []
            for i in range(len(self.data_set)):
                if count < 10:
                    count = count + 1
                    data_batch.append(self.data_set[i][1:self.len_local+1])
                    data_g_batch.append(self.global_data_set[i][1:self.len_global+1])
                    if self.data_set[i][0] == 0:
                        label_batch.append(0)
                    else:
                        label_batch.append(1)
                    continue
                else:
                    count = 0
                sample_ = torch.tensor(data_batch, dtype=torch.float32)
                # sample_g = torch.tensor(data_g_batch, dtype=torch.float32)
                label_ = torch.tensor(label_batch, dtype=torch.float32).unsqueeze(-1)
                #if self.data_set[i][0] != 0:
                #    label_ = torch.tensor(1, dtype=torch.float32).unsqueeze(0)
                pred = self.model(sample_)
                loss = loss_fn(pred, label_)
                loss_sum += loss.item()
                opimizer.zero_grad()
                loss.backward()
                opimizer.step()
                #grad = CrossEntropy_derivative(pred, label_)
                #self.model.back_probagation(grad)
                data_batch = []
                data_g_batch = []
                label_batch = []
        flag = True
        print(loss_sum)
        return flag
    '''
    def sample_mapping_process(self, K):
        self.privacy_demand = self.privacy_demand*np.exp(-K)
        self.global_data_set, self.sample_mapper = mapper_process(self.data_set, self.global_data_set, self.global_model.network, self.local_model.model, self.privacy_demand)
        self.global_model.database = self.global_data_set
    '''

    def test(self, e):
        row = []
        title = ["+", "-", "groundtrueth"]
        time_cost_start = time.time()
        row.append(title)
        c = 0
        for i in range(len(self.data_set_test)):
            #input_data = data_format_conversion([data[0:self.len_local]])
            #global_data = self.sample_mapper.target_net(input_data)
            # print(global_data)
            #global_res = self.global_model.network(global_data)
            #loc_res = self.local_model.model(input_data)
            #dis = np.linalg.norm(global_data.detach().numpy()-self.original_global_dataset[c][0:self.len_global])
            #aerfa = self.base*(1 - (1-np.exp(-dis*10))/(1+np.exp(-dis*10)))
            #res = aerfa*global_res + (1-aerfa)*loc_res
            sample_ = torch.tensor(self.data_set_test[i][1:self.len_local+1], dtype=torch.float32)
            # sample_g = torch.tensor(self.global_data_set_test[i][1:self.len_global+1], dtype=torch.float32)
            res = self.model(sample_)
            res = res.detach().numpy()[0]
            row.append([res, 1-res, self.data_set_test[i][0]])
            c += 1
        time_cost_end = time.time()
        self.time_cost = time_cost_end-time_cost_start
        csv_writer = CSVOperator("result/diabetes\Mine/"+ str(e) +"/"+self.model_path, 'w')
        csv_writer.write_row(row)
            
            

    def load_data(self):
        data_set_train = []
        global_data_set_train = []
        data_set_test = []
        global_data_set_test = []
        c = 0
        data_set_all = []
        for row in self.csv_operator.reader:
            if c == 0:
                c += 1
                continue
            data_set_all.append(row)
        rd.seed(self.client_id)
        rd.shuffle(data_set_all)
        for row in data_set_all:
            data_temp = []
            global_data_temp = []
            for i in range(len(row)):
                if row[i] != '-':
                    data_temp.append(float(str(row[i])))
                    if i in self.global_feature:
                        global_data_temp.append(float(str(row[i])))
            #if data_temp[-1] == 1 and rd.random()>0.4:
            #    data_set_train.append(np.array(data_temp))
            #    global_data_set_train.append(np.array(global_data_temp))
            if c < np.floor(len(data_set_all)*0.7):
                data_set_train.append(np.array(data_temp))
                global_data_set_train.append(np.array(global_data_temp))
                
            else:
                data_set_test.append(np.array(data_temp))
                global_data_set_test.append(np.array(global_data_temp))
            c += 1
        
        return data_set_train, global_data_set_train, data_set_test, global_data_set_test


def data_format_conversion(data_row):
        data_row = np.array(data_row)
        data_input = torch.tensor(data_row, dtype=torch.float32)
        return data_input