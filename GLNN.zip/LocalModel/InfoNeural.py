
import random as rd
import numpy as np
import torch
import torch.nn as nn
from sklearn import datasets
import matplotlib.pyplot as plt

def Softmax_derivative(x):
    x_ = x.detach().numpy()[0]
    temp = [[0 for i in range(len(x_))] for j in range(len(x_))]
    for i in range(len(x_)):
        for j in range(len(x_)):
            if i == j:
                temp[i][j] = x_[i]*(1-x_[j])
            else:
                temp[i][j] = -x_[i]*x_[j]
    #print(temp)
    return torch.tensor(temp, dtype=torch.float32)

def CrossEntropy_derivative(pred, label):
    if pred == 0:
        pred = 0.00001
    pred = (1/pred)*label - (1-label)/(1-pred)
    return -pred

def act_derivative(x, act):
    if act == 'sig':
        sig = nn.Sigmoid()
        return sig(x)*(1-sig(x))
    elif act == 'tanh':
        tanh = nn.Tanh()
        return 2*torch.pow(tanh(x), 3) - 2*tanh(x)
    return torch.ones_like(x)


def neural_derivative_w(in_put, w):
    # print(in_put.shape)
    in_put = in_put.unsqueeze(0)
    res = in_put
    for i in range(len(w)-1):
        res = torch.concat([res, in_put], dim=0)
    return res


def neural_derivative_in(w):
    return w



class TestNet(nn.Module):
    def __init__(self, in_d, out_d) -> None:
        super().__init__()
        self.classifier = nn.Sequential(
            nn.Linear(in_d, 64*in_d),
            nn.Sigmoid(),
            nn.Linear(64*in_d, 32*in_d),
            nn.Sigmoid(),
            nn.Linear(32*in_d, out_d),
            nn.Sigmoid()
        )
        self.in_ = 0
        self.linear_out = 0
        self.act_out = 0
    
    def forward(self, x):
        #self.in_ = x
        #self.linear_out = self.classifier[0](x)
        #self.act_out = self.classifier[1](self.linear_out)
        self.act_out = self.classifier(x)
        return self.act_out
    
    def back_probagation(self, grad, lr):
        # 损失函数对输出的偏导 乘上 激活函数对线性输出的偏导 得到 loss_act_g
        act_grad = act_derivative(self.linear_out, 'sig')
        for i in range(len(act_grad)):
            grad[i] = grad[i]*act_grad[i]
        loss_act_g = grad

        # 上一层的导数 乘上 线性部分对权值的导数，得到权值的梯度w_g
        w_g = neural_derivative_w(self.in_, self.classifier[0].weight.data)
        for i in range(len(loss_act_g)):
            w_g[i] = w_g[i]*loss_act_g
        
        # 更新权值
        self.classifier[0].weight.data -= lr*w_g



class InfoNeuralPart(nn.Module):
    def __init__(self, local_feature, lr_g, lr_l_g, lr_l_outspace, out_d_global, out_d_local, rand_len, hid_d_global) -> None:# local feature 包含了global_feature
        super().__init__()
        # learning rate
        self.lr_g = lr_g
        self.lr_l_g = lr_l_g
        self.lr_l_outspace = lr_l_outspace

        # local info net
        info_l_o = out_d_local
        self.local_len = local_feature
        self.info_l = nn.Linear(local_feature, info_l_o)
        self.info_l_act = nn.Sigmoid()
        self.info_l_act_name = "sig"

        # global info net
        info_g_i = hid_d_global
        self.rand_len = rand_len
        self.info_g_i = nn.Linear(info_l_o+self.rand_len, info_g_i)
        self.info_g_i_act = nn.Sigmoid()
        self.info_g_i_act_name = "sig"
        self.info_g_o = nn.Linear(info_g_i, out_d_global)
        self.info_g_o_act = nn.Sigmoid()
        self.info_g_o_act_name = "sig"
        self.info_global_o_ = ""
        self.info_local_o_ = ""
        self.rand_tensor = torch.rand(self.rand_len)
        self.info_local_ = ""
        self.global_info_input = ""
        self.info_global_ = ""
        self.info_global_input_h = ""
        self.info_global_output_h = ""
        self.x_l = ""

    def forward(self, x_l, x_g):
        # x_l contains x_g
        # get info_l and info_g
        #with torch.no_grad():
        self.x_l = x_l
        self.info_local_ = self.info_l(x_l)
        self.info_local_o_ = self.info_l_act(self.info_local_)
        if self.info_local_o_.ndim == 2:
            self.rand_tensor = torch.rand((len(self.info_local_o_), self.rand_len))
            self.global_info_input = torch.cat((self.info_local_o_, self.rand_tensor), dim=1)
        else:
            self.rand_tensor = torch.rand(self.rand_len)
            self.global_info_input = torch.cat((self.info_local_o_, self.rand_tensor))
        self.info_global_ = self.info_g_i(self.global_info_input)
        self.info_global_input_h = self.info_g_i_act(self.info_global_)
        self.info_global_output_h = self.info_g_o(self.info_global_input_h)
        self.info_global_o_ = self.info_g_o_act(self.info_global_output_h)

        # next layer input
        if self.info_local_o_.ndim == 2:
            input_c = torch.cat((self.info_local_o_, self.info_global_o_, x_g), dim=1)
        else:
            input_c = torch.cat((self.info_local_o_, self.info_global_o_, x_g))

        # get pred
        return input_c

    def back_propagation(self, grad):
        with torch.no_grad():
            info_global_grad = grad[1] # 上层网络传回来的梯度
            #info_g 求导模块#
            # info_g 输出层的激活函数对其输入求导
            info_g_o_act = act_derivative(self.info_global_output_h, self.info_g_o_act_name)

            # info_g 输出层的激活函数的输入对输出层的权值求导
            info_g_o_w = neural_derivative_w(self.info_global_input_h, self.info_g_o.weight.data)

            # info_g 输出层的激活函数的输入对输出层的输入求导
            info_g_o_in = neural_derivative_in(self.info_g_o.weight.data)

            # info_g 输出层的输入对输入层的激活函数输入求导
            info_g_i_act = act_derivative(self.info_global_, self.info_g_i_act_name)

            # info_g 输入层的激活函数输入对输入层的权值求导
            info_g_i_w = neural_derivative_w(self.global_info_input, self.info_g_i.weight.data)

            # info_g 对info_l的输出求导
            info_l_o_grad = neural_derivative_in(self.info_g_i.weight.data)

            # 上层网络传回来的梯度 乘上 info_g 输出层的激活函数对其输入的导数 得到info_g_o
            # info_g_o = info_global_grad.T*info_g_o_act
            info_global_grad = info_global_grad.T
            for i in range(len(info_g_o_act)):
                info_global_grad[i] = info_global_grad[i]*info_g_o_act[i]
            info_g_o = info_global_grad.T

            # info_g 输出层的激活函数对其输入的导数乘 info_g 输出层的激活函数的输入对输出层的权值导数 得到w_o_g
            # w_o_g = info_g_o.T*info_g_o_w
            w_o_g = torch.matmul(info_g_o, info_g_o_w)
            # 更新权值
            self.info_g_o.weight.data = self.info_g_o.weight.data - self.lr_g*w_o_g

            # 输出层的激活函数对其输入的导数 乘上 info_g 输出层的激活函数的输入对输出层的输入导数 得到g_1
            # g_1 = info_g_o_act*info_g_o_in
            g_1 = torch.matmul(info_g_o, info_g_o_in)
            # g_1 乘上 info_g 输出层的输入对输入层的激活函数输入的导数 得到g_2
            # g_2 = g_1*info_g_i_act
            g_1 = g_1.T
            for i in range(len(info_g_i_act)):
                g_1[i] = g_1[i]*info_g_i_act[i]
            g_2 = g_1.T
            # g_2 乘上 info_g 输入层的激活函数输入对输入层的权值的导数 得到w_i_g
            w_i_g = torch.matmul(g_2, info_g_i_w)
            # 更新权值
            self.info_g_i.weight.data = self.info_g_i.weight.data - self.lr_g*w_i_g

            # g_2 乘上 info_g 对info_l的输出的导数 得到g_in_l
            g_in_l = torch.matmul(g_2, info_l_o_grad)


            # info_l 求导模块#
            # 分类网络传回的梯度
            info_local_grad = grad[0]
            # info_g 传回的梯度
            info_l_grad = g_in_l[0:self.local_len]

            # info_l 输出对输出层激活函数的输入求导
            info_l_o_act = act_derivative(self.info_local_, self.info_l_act_name)

            # info_l 输出层激活函数的输入对输出层的权值求导
            info_l_o_w = neural_derivative_w(self.x_l, self.info_l.weight.data)

            # info_l 输出层外的梯度要分开算
            #######################################
            # 对于上一层传回来的梯度
            # 上一层传回来的梯度 乘上 info_l 输出对输出层激活函数的输入求导 得到g_1
            # g_1 = info_local_grad*info_l_o_act
            info_local_grad = info_local_grad.T
            for i in range(len(info_l_o_act)):
                info_local_grad[i] = info_local_grad[i]*info_l_o_act[i]
            g_1 = info_local_grad.T

            # g_1 乘上 info_l 输出层激活函数的输入对输出层的权值求导 得到w_l_g
            #w_l_g = g_1 * info_l_o_w
            w_l_g = torch.matmul(g_1, info_l_o_w)
            # 更新权值
            self.info_l.weight.data = self.info_l.weight.data - self.lr_l_outspace*w_l_g

            #################################################
            # 对于全局信息网络回传的梯度
            # info_l 输出层外的梯度 乘上 info_l 输出对输出层激活函数的输入求导 得到g_1
            # g_1 = info_l_grad*info_l_o_act
            info_l_grad = info_l_grad.T
            for i in range(len(info_l_o_act)):
                info_l_grad[i] = info_l_grad[i]*info_l_o_act[i]
            g_1 = info_l_grad.T

            # g_1 乘上 info_l 输出层激活函数的输入对输出层的权值求导 得到w_l_g
            #w_l_g = g_1 * info_l_o_w
            w_l_g = torch.matmul(g_1, info_l_o_w)
            # 更新权值
            self.info_l.weight.data = self.info_l.weight.data - self.lr_l_g*w_l_g


class InfoNeuralLayer(nn.Module):
    def __init__(self, local_feature, global_feature, lr_g, lr_l_g, lr_l_outspace, lr, out_d) -> None:
        super().__init__()
        self.lr = lr
        self.hid_d_global = 16
        self.out_d_global = 2
        self.out_d_local = 2
        self.rand_len = 2
        self.info_part = InfoNeuralPart(local_feature, lr_g, lr_l_g, lr_l_outspace, self.out_d_global, self.out_d_local, self.rand_len, self.hid_d_global)
        self.linear = nn.Linear(self.out_d_global+self.out_d_local+global_feature, out_d)
        self.act = nn.Sigmoid()
        self.act_name = 'sig'
        self.linear_out = 0
        self.act_out = 0
        self.x_in = 0
        self.x_l = 0
        self.x_g = 0
    
    def forward(self, x_l, x_g):
        #with torch.no_grad():
        self.x_l = x_l
        self.x_g = x_g
        self.x_in = self.info_part(x_l, x_g)
        self.linear_out = self.linear(self.x_in)
        self.act_out = self.act(self.linear_out)
        return self.act_out
    
    def back_propagation(self, grad):# grad是上一层传回的grad
        with torch.no_grad():
            # 激活函数的输出对激活函数的输入求导
            act_de = act_derivative(self.linear_out, self.act_name)
            grad = grad.T
            # print(act_de)
            for i in range(len(act_de)):
                grad[i] = grad[i]*act_de[i]
            act_de = grad
            # 激活函数的输入对隐含层的权值求导
            w_h = neural_derivative_w(self.x_in, self.linear.weight.data)
            #w_h = torch.matmul(act_de, w_h)
            w_h = torch.matmul(act_de, w_h)
            #for i in range(len(w_h)):
                #w_h[i] = w_h[i]*act_de[i]
            # 更新权值
            self.linear.weight.data = self.linear.weight.data - self.lr*w_h
            # print(self.linear.weight.data)
            # 激活函数的输入对网络的输入求导
            act_de = act_de.T
            in_grad = neural_derivative_in(self.linear.weight.data)
            in_grad = torch.matmul(act_de, in_grad)

            # 获取infopart的梯度
            if in_grad.ndim == 1:
                in_grad = in_grad.unsqueeze(0)
            info_l_grad = in_grad[0][0:self.out_d_local]
            info_g_grad = in_grad[0][self.out_d_local:self.out_d_local+self.out_d_global]
            res_grad = in_grad[0][self.out_d_local+self.out_d_global:]
            c = 0
            for grad_ in in_grad:
                if c == 0:
                    c += 1
                    continue
                info_l_grad = torch.cat([info_l_grad, grad_[0:self.out_d_local]])
                info_g_grad = torch.cat([info_g_grad, grad_[self.out_d_local:self.out_d_local+self.out_d_global]])
                res_grad = torch.cat([res_grad, grad_[self.out_d_local+self.out_d_global:]])
            grad_info = [info_g_grad, info_l_grad]
            # print(grad_info)
            self.info_part.back_propagation(grad_info)#infopart进行反向传播
        return res_grad

    def get_weight_info(self):
        return self.linear.weight.data# , self.info_part.info_global_o_
    
    def set_weight(self, weight):
        self.linear.weight.data = weight


class InfoNeural(nn.Module):
    def __init__(self, local_d, global_d, out_d) -> None:
        super().__init__()
        self.infolayer1 = InfoNeuralLayer(local_d, global_d, 0.01, 0.01, 0.01, 0.01, 4*global_d)
        self.infolayer2 = InfoNeuralLayer(local_d + 4*global_d, 4*global_d, 0.01, 0.01, 0.01, 0.01, 2*global_d)
        self.infolayer3 = InfoNeuralLayer(local_d + 2*global_d, 2*global_d, 0.01, 0.01, 0.01, 0.01, out_d)
    
    def forward(self, x_l, x_g):
        pred = self.infolayer1(x_l, x_g)
        if x_l.ndim == 2:
            x = torch.cat([x_l, pred], dim=1)
            pred = self.infolayer2(x, pred)
            x = torch.cat([x_l, pred], dim=1)
            pred = self.infolayer3(x, pred)
        else:
            x = torch.cat([x_l, pred])
            pred = self.infolayer2(x, pred)
            x = torch.cat([x_l, pred])
            pred = self.infolayer3(x, pred)
        return pred
    
    def back_probagation(self, grad):
        grad = self.infolayer3.back_propagation(grad)
        grad = self.infolayer2.back_propagation(grad)
        self.infolayer1.back_propagation(grad)
    
    def get_weight(self, layer):
        if layer == 0:
            return self.infolayer1.get_weight_info()
        if layer == 1:
            return self.infolayer2.get_weight_info()
        if layer == 2:
            return self.infolayer3.get_weight_info()
    
    def set_weight(self, layer, weight):
        if layer == 0:
            return self.infolayer1.set_weight(weight)
        if layer == 1:
            return self.infolayer2.set_weight(weight)
        if layer == 2:
            return self.infolayer3.set_weight(weight)
        


def square_distribution(a, b, c, num):
    x = []
    y = []
    for i in range(num):
        t = rd.random()
        t2 = rd.random()
        x.append(np.array([t, t2]))
        if t2 > a*t*t + b*t + c:
            y.append(1)
        else:
            y.append(0)
    return x, y

def sin_distribution(A, b, w, num):
    x = []
    y = []
    for i in range(num):
        t = rd.random()
        t2 = rd.random()
        x.append(np.array([t, t2]))
        if t2 > A*np.sin(w*t+b):
            y.append(1)
        else:
            y.append(0)
    return x, y

def generate_data(hidden_feature):
    # first no hidden feature
    dataset = []
    if hidden_feature is False:
        #x_m, y_m = datasets.make_circles(noise=0.05)
        #x_c, y_c = datasets.make_circles(noise=0.05)
        x_m, y_m = square_distribution(1, -0.05, 0.3, 400)
        x_c, y_c = sin_distribution(1, 0.46, 0.73, 400)
        dataset1 = []
        dataset1_test = []
        dataset2 = []
        dataset2_test = []
        for i in range(len(x_m)):
            if rd.random() < 0.7:
                dataset1.append([x_m[i], y_m[i]])
                dataset2.append([x_c[i], y_c[i]])
            else:
                dataset1_test.append([x_m[i], y_m[i]])
                dataset2_test.append([x_c[i], y_c[i]])
        return [dataset1, dataset2, dataset1_test, dataset2_test]
    else:
        x_g, y_g = datasets.make_moons(noise=0.05)
        x_l_m, y_l_m = datasets.make_moons(noise=0.05)
        x_l_c, y_l_c = datasets.make_circles(noise=0.05)
        # dataset allocate
        dataset1 = []
        dataset1_test = []
        dataset2 = []
        dataset2_test = []
        for i in range(len(x_l_m)):
            if rd.random() < 0.7:
                dataset1.append([x_l_m[i], x_g[i], y_g[i]])
                dataset2.append([x_l_c[i], x_g[i], y_g[i]])
            else:
                dataset1_test.append([x_l_m[i], x_g[i], y_g[i]])
                dataset2_test.append([x_l_c[i], x_g[i], y_g[i]])
        return [dataset1, dataset2, dataset1_test, dataset2_test]


def test():
    hidden_feature = False
    dataset = generate_data(hidden_feature)
    # set1
    train_set1 = dataset[0]
    train_sample1 = train_set1[0]
    # set2
    train_set2 = dataset[1]
    train_sample2 = train_set2[0]
    # test_set1
    test_set1 = dataset[2]
    test_sample1 = test_set1[0]
    
    # test_set1
    test_set2 = dataset[3]
    test_sample2 = test_set2[0]

    # models
    classifier = TestNet(len(train_sample1[0]), 1)
    net = InfoNeural(len(train_sample1[0]), len(train_sample1[0]), 1)
    net2 = InfoNeural(len(train_sample2[0]), len(train_sample2[0]), 1)
    #fed_bn = FedBN(len(train_sample1[0]), 1)

    # loss_fn
    loss_fn = nn.BCELoss()

    # optimizer
    optimizer = torch.optim.SGD(classifier.parameters(), lr=0.01)
    optimizer2 = torch.optim.SGD(net.parameters(), lr=0.01)
    optimizer3 = torch.optim.SGD(net2.parameters(), lr=0.01)
    # tool = DerivativeChain(classifier.classification)
    echo = 1000
    # loss_sum = 0
    loss_avg = []
    loss_net1 = []
    loss_net2 = []
    best_Avg = 0
    best_BN = 0
    best_GLNN = 0
    lowest_loss_Avg = 9999
    lowest_loss_GLNN = 9999
    lowest_loss_BN = 9999
    for e in range(echo):
        loss_sum2 = 0
        loss_sum = 0
        loss_sum3 = 0
        count = 0
        data_batch = []
        data_g_batch = []
        label_batch = []
        for i in range(len(train_set1)):# 训练第一个数据集
            if count < 10:
                count = count + 1
                data_batch.append(train_set1[i][0])
                data_g_batch.append(train_set1[i][0])
                label_batch.append(train_set1[i][1])
                continue
            else:
                count = 0
            sample_ = torch.tensor(data_batch, dtype=torch.float32)
            label_ = torch.tensor(label_batch, dtype=torch.float32).unsqueeze(-1)
            pred_class = classifier(sample_)
            pred_info = net(sample_, sample_)
            #pred_bn = fed_bn(sample_.unsqueeze(0))
            loss = loss_fn(pred_class, label_)
            loss2 = loss_fn(pred_info, label_)
            #loss3 = loss_fn(pred_bn, label_)
            loss_sum2 += loss2.item()
            loss_sum += loss.item()
            #loss_fd += loss3
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            optimizer2.zero_grad()
            loss2.backward()
            optimizer2.step()
            #grad = CrossEntropy_derivative(pred_info, label_)
            #net.back_probagation(grad)
            data_batch = []
            data_g_batch = []
            label_batch = []

        data_batch = []
        data_g_batch = []
        label_batch = []
        for i in range(len(train_set2)):# 训练第二个数据集
            if count < 10:
                count = count + 1
                data_batch.append(train_set2[i][0])
                data_g_batch.append(train_set2[i][0])
                label_batch.append(train_set2[i][1])
                continue
            else:
                count = 0
            sample_ = torch.tensor(data_batch, dtype=torch.float32)
            label_ = torch.tensor(label_batch, dtype=torch.float32).unsqueeze(-1)
            pred_class = classifier(sample_)
            pred_info = net2(sample_, sample_)
            #pred_bn = fed_bn(sample_.unsqueeze(0))
            loss = loss_fn(pred_class, label_)
            loss3 = loss_fn(pred_info, label_)
            #loss3 = loss_fn(pred_bn, label_)
            loss_sum3 += loss3.item()
            loss_sum += loss.item()
            #loss_fd += loss3
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            optimizer3.zero_grad()
            loss3.backward()
            optimizer3.step()
            #grad = CrossEntropy_derivative(pred_info, label_)
            #net.back_probagation(grad)
            data_batch = []
            data_g_batch = []
            label_batch = []

        loss_avg.append(loss_sum/2)
        loss_net1.append(loss_sum2)
        loss_net2.append(loss_sum3)
        lowest_loss_Avg = loss_sum/2
        lowest_loss_GLNN = (loss_sum2 + loss_sum3)/2
        print(loss_sum/2, loss_sum2, loss_sum3, e)
        # 聚合操作
        for l in range(3):
            #print(net.get_weight(l))
            #print(net2.get_weight(l))
            weight = (net.get_weight(l) + net2.get_weight(l))/2
            net.set_weight(l, weight)
            net2.set_weight(l, weight)
            #print(net.get_weight(l))
            #print(net2.get_weight(l))



        correct_class = 0
        correct_net = 0
        correct_net2 = 0

        count = 0

        for i in range(len(test_set1)):

                
                sample_ = torch.tensor(test_set1[i][0], dtype=torch.float32)
                label_ = torch.tensor(test_set1[i][1], dtype=torch.float32).unsqueeze(0)
                sample_2 = torch.tensor(test_set2[i][0], dtype=torch.float32)
                label_2 = torch.tensor(test_set2[i][1], dtype=torch.float32).unsqueeze(0)
                pred_class = classifier(sample_)
                pred_info = net(sample_, sample_)
                pred_info2 = net2(sample_2, sample_2)
                if (pred_class > 0.5 and 1 == label_) or (pred_class < 0.5 and 0 == label_):
                    correct_class += 1
                if (pred_info > 0.5 and 1 == label_) or (pred_info < 0.5 and 0 == label_):
                    correct_net += 1
                pred_class = classifier(sample_2)
                if (pred_class > 0.5 and 1 == label_2) or (pred_class < 0.5 and 0 == label_2):
                    correct_class += 1
                if (pred_info2 > 0.5 and 1 == label_2) or (pred_info2 < 0.5 and 0 == label_2):
                    correct_net2 += 1    
        acc_Avg = correct_class/(len(test_set1)*2)
        acc_GLNN = (correct_net/len(test_set1)+correct_net2/len(test_set2))/2
        if best_Avg < acc_Avg:
            best_Avg = acc_Avg
        if best_GLNN < acc_GLNN:
            best_GLNN = acc_GLNN
        

    x = range(0, echo)
    labels = ["FedAvg, FedInfo2, FedInfo3"]
    plt.plot(x, loss_avg)
    plt.plot(x, loss_net1)
    plt.plot(x, loss_net2)
    plt.ylabel("loss")
    plt.ylim(0, 250)
    plt.xlabel(" rounds ")
    plt.legend(labels)
    plt.show()
    
    

#test()            



