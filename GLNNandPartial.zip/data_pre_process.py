import data_organization.daibetes_kaggle as pre


pre.run()

