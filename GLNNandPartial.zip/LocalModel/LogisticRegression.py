import torch
import torch.nn as nn
from torch.autograd import Variable as v
import numpy as np


class LogisticRegression(nn.Module):
    def __init__(self, input_dimension):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dimension, 2),
            nn.Softmax()
        )

    def forward(self, input_x):
        result = self.net(input_x)
        return result

    @staticmethod
    def data_format_conversion(data_row):
        data_row = np.array(data_row)
        data_input = torch.tensor(data_row, dtype=torch.float32)
        return data_input

    def learning_process(self, data_set):  # 所有的行，最后一列为label
        echo = 300
        optimizer = torch.optim.Adam(self.net.parameters(), lr=0.01)
        loss_fn = nn.CrossEntropyLoss()
        for i in range(echo):
            sum_loss = 0
            for data in data_set:
                input_features = self.data_format_conversion([data[0:len(data)-1]])
                label = 0
                if data[-1] == 0:
                    label = torch.tensor([[1,0]], dtype = torch.float32)
                else:
                    label = torch.tensor([[0,1]], dtype = torch.float32)
                pred = self.net(input_features)
                
                # pred = torch.unsqueeze(pred,0)
                # print(pred.unsqueeze(0))
                #label = label.unsqueeze(0)
                # pred = pred.unsqueeze(0)
                #print(label)
                # print(pred)
                loss = loss_fn(pred, label)
                sum_loss += loss
            optimizer.zero_grad()
            sum_loss.backward()
            # print(sum_loss)
            optimizer.step()

    def save_model(self, model_name):
        torch.save(self.net, "model/" + str(self.option) + "/" + model_name + ".model")

    def load_model(self, path):
        self.net = torch.load(path)





