import GlobalModel.noise_generator as noi
import numpy as np
from random import randint
import GlobalModel.neural_net_work as net
from torch.autograd import Variable as v
import torch 
import threading
import torch.nn as nn


class ClientGlobal():
    def __init__(self, ID, input_dimension, output_dimension) -> None:
        # self.lable = randint()%2
        self.database = []
        # self.weight = []
        self.gradient = []
        self.echo = 100
        self.clientID = ID
        self.network = net.NeuralNetWork(input_dimension, output_dimension).to(device='cpu')
        self.loss_fn = torch.nn.CrossEntropyLoss()
        self.optimizer = torch.optim.SGD(self.network.parameters(), lr=0.01)
        self.pred = 0
        self.sum_loss = 0
        self.epsilon = 1
        self.lamda = 2
        self.scaler = self.lamda
        self.K = 1
        self.dp_round = 1
    '''
    def noise_generator():
        noise = 0
        return noise
    '''
    def learning_algorithm(self, K):
        # self.network = net.NeuralNetWork().to(device='cpu')
        # self.loss_fn = torch.nn.CrossEntropyLoss()
        # self.optimizer = torch.optim.SGD(self.network.parameters(), lr=0.01)
        # self.load_model("model/" + str(self.clientID) + ".model")
        self.K = K+1
        echo = 10
        for m in range(echo):
            self.sum_loss = 0
            for item in self.database:
                sample = torch.tensor([item[0:len(item)-1]],dtype=torch.float32)
                label = ""
                if item[-1] == 1:
                    label = v(torch.tensor([[1,0]], dtype = torch.float32))
                else:
                    label = v(torch.tensor([[0,1]], dtype = torch.float32))
                self.pred = self.network(sample)
                # self.pred = self.pred.unsqueeze(0)
                # print(self.pred)
                # print(label)    
                loss = self.loss_fn(self.pred, label)
                self.sum_loss += loss
            self.optimizer.zero_grad()
            self.sum_loss.backward()
            self.optimizer.step()

    def optimize_step(self, gradient_after_aggregation):
        self.gradient = gradient_after_aggregation
        self.pred = self.gradient
        
        self.optimizer.step()
    
    def save_model(self, path):
        torch.save(self.network, "model\\" + path + ".model")

    def test(self, test_data):
        pre = self.network(test_data)
        return pre
    
    def load_model(self, path):
        self.network = torch.load(path)

    def set_weight(self, level, weight_outspace):
        self.network.set_weight(level=level, weight_outspace=weight_outspace)
        

    def get_weight(self, level):
        weight = self.network.get_weight(level=level)
        if self.dp_round == 1:
            self.dp_round = 2
            data = weight.data.detach().numpy()
            for i in range(len(data)):
                np.add(data[i], noi.add_laplace_noise(len(data[i]), 0, self.epsilon, self.lamda))
                data[i] = [min(max(x, 1),-1) for x in data[i]]
            weight.data = torch.tensor(data)
            return weight
        data = weight.data.detach().numpy()
        for i in range(len(data)):
            data[i] = [min(max(x, 1),-1) for x in data[i]]
        weight.data = torch.tensor(data)
        return  weight


