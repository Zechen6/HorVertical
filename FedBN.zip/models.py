from turtle import forward
import torch
import torch.nn as nn
import torch.nn.functional as func
from collections import OrderedDict
import numpy as np

class DigitModel(nn.Module):
    """
    Model for benchmark experiment on Digits. 
    """
    def __init__(self, in_di, num_classes):
        super(DigitModel, self).__init__()

        #self.conv1 = nn.Conv2d(3, 64, 5, 1, 2)
        #self.bn1 = nn.BatchNorm2d(64)
        #self.conv2 = nn.Conv2d(64, 64, 5, 1, 2)
        #self.bn2 = nn.BatchNorm2d(64)
        #self.conv3 = nn.Conv2d(64, 128, 5, 1, 2)
        #self.bn3 = nn.BatchNorm2d(128)
    
        #self.fc1 = nn.Linear(6272, 2048)
        #self.bn4 = nn.BatchNorm1d(2048)
        #self.fc2 = nn.Linear(2048, 512)
        #self.bn5 = nn.BatchNorm1d(512)
        #self.fc3 = nn.Linear(512, num_classes)
        self.classification = nn.Sequential(
            nn.Linear(in_di, 120),
            nn.BatchNorm1d(120),
            nn.ReLU(),
            nn.Linear(120, 120),
            nn.BatchNorm1d(120),
            nn.ReLU(),
            nn.Linear(120, num_classes),
            nn.Sigmoid()
        )
        self.model_list = ['0','3', '6']

    def set_weight(self, level, weight_outspace):
        self.classification._modules[self.model_list[level]].weight.data = weight_outspace

    def get_weight(self, level):
        return self.classification._modules[self.model_list[level]].weight.data

    def forward(self, x):
        #x = func.relu(self.bn1(self.conv1(x)))
        #x = func.max_pool2d(x, 2)

        #x = func.relu(self.bn2(self.conv2(x)))
        #x = func.max_pool2d(x, 2)

        #x = func.relu(self.bn3(self.conv3(x)))

        #x = x.view(x.shape[0], -1)

        #x = self.fc1(x)
        #x = self.bn4(x)
        #x = func.relu(x)

        #x = self.fc2(x)
        #x = self.bn5(x)
        #x = func.relu(x)

        #x = self.fc3(x)
        x = self.classification(x)
        return x
    


class AlexNet(nn.Module):
    """
    used for DomainNet and Office-Caltech10
    """
    def __init__(self, num_classes=10):
        super(AlexNet, self).__init__()
        self.features = nn.Sequential(
            OrderedDict([
                ('conv1', nn.Conv2d(3, 64, kernel_size=11, stride=4, padding=2)),
                ('bn1', nn.BatchNorm2d(64)),
                ('relu1', nn.ReLU(inplace=True)),
                ('maxpool1', nn.MaxPool2d(kernel_size=3, stride=2)),

                ('conv2', nn.Conv2d(64, 192, kernel_size=5, padding=2)),
                ('bn2', nn.BatchNorm2d(192)),
                ('relu2', nn.ReLU(inplace=True)),
                ('maxpool2', nn.MaxPool2d(kernel_size=3, stride=2)),

                ('conv3', nn.Conv2d(192, 384, kernel_size=3, padding=1)),
                ('bn3', nn.BatchNorm2d(384)),
                ('relu3', nn.ReLU(inplace=True)),

                ('conv4', nn.Conv2d(384, 256, kernel_size=3, padding=1)),
                ('bn4', nn.BatchNorm2d(256)),
                ('relu4', nn.ReLU(inplace=True)),

                ('conv5', nn.Conv2d(256, 256, kernel_size=3, padding=1)),
                ('bn5', nn.BatchNorm2d(256)),
                ('relu5', nn.ReLU(inplace=True)),
                ('maxpool5', nn.MaxPool2d(kernel_size=3, stride=2)),
            ])
        )
        self.avgpool = nn.AdaptiveAvgPool2d((6, 6))

        self.classifier = nn.Sequential(
            OrderedDict([
                ('fc1', nn.Linear(256 * 6 * 6, 4096)),
                ('bn6', nn.BatchNorm1d(4096)),
                ('relu6', nn.ReLU(inplace=True)),

                ('fc2', nn.Linear(4096, 4096)),
                ('bn7', nn.BatchNorm1d(4096)),
                ('relu7', nn.ReLU(inplace=True)),
            
                ('fc3', nn.Linear(4096, num_classes)),
            ])
        )

    def forward(self, x):
        x = self.features(x)
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.classifier(x)
        return x


class classifier(nn.Module):
    def __init__(self, in_d, out_d) -> None:
        super().__init__()
        self.classifier = nn.Sequential(
            nn.Linear(in_d, 64*in_d),
            nn.Sigmoid(),
            nn.Linear(64*in_d, 32*out_d),
            nn.Sigmoid(),
            nn.Linear(32*out_d, out_d),
            nn.Softmax()
        )
    
    def forward(self, x):
        pred = self.classifier(x)
        return pred


def test():
    model = DigitModel(2, 1)
    loss_fn = nn.BCELoss()
    optimizer = torch.optim.SGD(model.parameters(), lr=0.01)
    input = []
    label = []
    for i in range(100):
        input.append(torch.rand((12,2,2)))
        print(input)
        label.append(torch.rand((12,2,1)))
    
    for e in range(100):
        sum_loss = 0
        for i in range(len(input)):
            pred = model(input[i])
            loss = loss_fn(pred, label[i])
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            sum_loss += loss.item()
        print(sum_loss)

# test()
