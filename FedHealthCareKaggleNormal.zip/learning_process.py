
from client import Client
import GlobalModel.Server as Server
import os
from CVSOperator import CSVOperator

model_path = "\\diabetes\\"
data_set_o = "dataset\\diabetes\\pre_operate\\step2\\"
data_sets = os.listdir(data_set_o)

clients = []
K = range(2, 6, 2)
time_cost_server = 0
time_cost_client = 0
total_clients = len(data_sets)
center_server = Server.Server()
for i in range(total_clients):
    clients.append(Client(data_set_o + data_sets[i], 0, i, data_sets[i]))
# center_server.clients_pool = clients
center_server.clients_num = total_clients
center_server.clients_pool = clients
for echo in range(1):
    # total_clients = len(data_sets)
    # for c in clients:
    #     c.train_local_model()
    for e in range(4000):
        cn = 0
        for c in clients:
            cn += 1
            print(cn)
            # c.train_local_model()
            # if e >= 1:
            #     c.sample_mapping_process(e)
            center_server.grad_pool.append(c.global_model.learning_algorithm(e))
            # sum_loss += c.global_model.sum_loss
        print("---------")
        print(e)
        print("---------")
        center_server.aggregate_weight(clients)
        # center_server.grad_pool.clear()
        # print(center_server.time_cost)
        time_cost_server = center_server.time_cost/float(e+1)
        # print(time_cost_server)

        for c in clients:
            # if e >= 1:
                c.test(e+1)
                time_cost_client += c.time_cost
        # c.global_model.save_model(model_path + c.model_path)
csv_writer = CSVOperator("result/diabetes/time_analysis/Mine/timecost_client.csv",'w')
csv_writer.write_row([[time_cost_client]])
csv_writer.end()
csv_writer = CSVOperator("result/diabetes/time_analysis/Mine/timecost_server.csv",'w')
csv_writer.write_row([[time_cost_server]])
csv_writer.end()
