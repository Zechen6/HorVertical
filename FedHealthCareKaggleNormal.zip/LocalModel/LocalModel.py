from LocalModel.LogisticRegression import LogisticRegression
import torch


class LocalModel:
    def __init__(self, option, input_dimension):
        self.option = option
        if option == 0:
            self.model = LogisticRegression(input_dimension).to(device='cpu')

    def save_model(self, model_name):
        self.model.save_model(model_name)

    def load_model(self, path):
        self.model.load_model(path)
