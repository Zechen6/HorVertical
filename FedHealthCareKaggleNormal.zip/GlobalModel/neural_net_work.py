import re
from numpy import float32
import torch.nn as nn
import torch
from torch.autograd import Variable as v
from torch.nn import functional as F
import GlobalModel.noise_generator as noi
import numpy as np


class NeuralNetWork(nn.Module):
    def __init__(self, input_dimension, output_dimension) -> None:
        super(NeuralNetWork,self).__init__()
        self.classification = nn.Sequential(
            nn.Linear(input_dimension, 10*input_dimension*output_dimension),
            nn.Sigmoid(),
            nn.Linear(10*input_dimension*output_dimension, 10*input_dimension*output_dimension),
            nn.Sigmoid(),
            nn.Linear(10*input_dimension*output_dimension, output_dimension),
            nn.Sigmoid()
        )
        self.model_list = ['0', '2', '4']

    def set_weight(self, level, weight_outspace):
        self.classification._modules[self.model_list[level]].weight.data = nn.Parameter(weight_outspace)

    def get_weight(self, level):
        return self.classification._modules[self.model_list[level]].weight + noi.add_noise()

    def forward(self, x):
        logits = self.classification(x)

        return logits


class Decoupling(nn.Module):
    def __init__(self, in_d, out_d) -> None:
        super().__init__()
        self.classifier = nn.Sequential(
            nn.Linear(in_d, 64*in_d),
            nn.Sigmoid(),
            nn.Linear(64*in_d, 32*in_d),
            nn.Sigmoid(),
            nn.Linear(32*in_d, out_d),
            nn.Sigmoid()
        )
        self.in_ = 0
        self.linear_out = 0
        self.act_out = 0
        self.properation = 0.5
        self.global_index1 = int(np.floor(self.properation*len(self.properation*self.classifier._modules['0'].weight)))
        self.global_index2 = int(np.floor(self.properation*len(self.properation*self.classifier._modules['2'].weight)))
        self.global_index3 = int(np.floor(self.properation*len(self.properation*self.classifier._modules['4'].weight)))
    
    def forward(self, x):
        #self.in_ = x
        #self.linear_out = self.classifier[0](x)
        #self.act_out = self.classifier[1](self.linear_out)
        self.act_out = self.classifier(x)
        return self.act_out

    def set_weight(self, level, weight_outspace):
        layer = level
        weight = weight_outspace
        if layer == 0:
            for i in range(len(weight)):
                self.classifier._modules['0'].weight.data[i+self.global_index1] = weight[i]
        if layer == 1:
            for i in range(len(weight)):
                self.classifier._modules['2'].weight.data[i+self.global_index2] = weight[i]
        if layer == 2:
            for i in range(len(weight)):
                self.classifier._modules['4'].weight.data[i+self.global_index3] = weight[i]
    
    def get_weight(self, level):
        layer = level
        if layer == 0:
            g =  self.classifier._modules['0'].weight
            global_tensor = torch.zeros([int((len(g)-self.global_index1)),int(len(g[0]))])
            for i in range(len(global_tensor)):
                global_tensor[i] = g[i+self.global_index1]
            return global_tensor
        if layer == 1:
            g =  self.classifier._modules['2'].weight
            global_tensor = torch.zeros([int((len(g)-self.global_index2)),int(len(g[0]))])
            for i in range(len(global_tensor)):
                global_tensor[i] = g[i+self.global_index2]
            return global_tensor
        if layer == 2:
            g =  self.classifier._modules['4'].weight
            global_tensor = torch.zeros([int((len(g)-self.global_index3)),int(len(g[0]))])
            for i in range(len(global_tensor)):
                global_tensor[i] = g[i+self.global_index3]
            return global_tensor


def test():
    
    model = NeuralNetWork().to(device='cpu')
    loss_fn = torch.nn.CrossEntropyLoss()
    # print(model.classification._modules['0'].weight)
    # model.classification._modules['0'].weight = nn.Parameter(torch.zeros(2, 10).to(torch.device('cpu')))
    # print(model.classification._modules['0'].weight)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.01)
    # print(model.parameters)

    sig = nn.Sigmoid()
    for echo in range(100):
        shape = torch.tensor([[1,2]])
        x = v(shape.to(torch.float32), requires_grad = True)
        # shape = torch.tensor([1])
        shape = torch.tensor([[0,0]])
        y = v(torch.zeros_like(shape, dtype=torch.float32).softmax(dim=1))
        pred = model(x)
        # print(pred.shape)
        # print(y.shape)
        loss = loss_fn(pred, y)
        # print(pred.grad)
        optimizer.zero_grad()
        # print(model.classification._modules['0'].weight.grad)
        loss.backward()
        
        # print(loss)
        # print(model.classification._modules['0'].weight.grad)
        optimizer.step()
    # print(model.classification._modules['0'].weight)

# test()